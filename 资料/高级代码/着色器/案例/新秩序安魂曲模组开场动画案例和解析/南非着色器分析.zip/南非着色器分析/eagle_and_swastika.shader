// ==============================================================
// 文件名：eagle_and_swastika.shader
// 作用：控制钢铁雄心4中"鹰与卍字标志"的显示效果与动态动画
// 适用场景：游戏中具有象征意义的核心标志（如特定势力的徽章、标志性符号等）
// 核心功能：通过纹理坐标变换实现标志的仪式感动态变换，包括：
//          - 正常状态：26~34秒内，先横向缩放展开→再纵向位移动画→最后正常显示；
//          - 禁用状态：26.5~34秒（比正常状态晚0.5秒），类似变换但位移更平缓、显示范围稍大；
//          - 交互反馈：按下时标志变暗、悬停时标志变亮（保持核心符号视觉一致性）。
// 与其他元素的核心差异：
//          1. 动画焦点：作为核心符号，动画聚焦于"出现/变换"的仪式感，强调动态过程的精致性；
//          2. 时间特性：时间窗口精确且短暂（仅8秒左右），与标志的重要性匹配；
//          3. 变换逻辑：通过横向缩放与纵向位移的组合动画，而非单纯缩放或燃烧，突出符号的独特性。
// ==============================================================


// ==============================================================
// 引入外部工具包（复用通用功能）
// 无需燃烧效果工具，核心是基础动画和状态判断
// ==============================================================
Includes = {
    "buttonstate.fxh"      // 按钮状态逻辑（按下/悬停判断）
    "sprite_animation.fxh" // 精灵动画函数（支持标志的动态变换）
}


// ==============================================================
// 像素着色器采样器（Samplers）：定义纹理读取规则
// 针对标志类元素优化，确保符号边缘清晰、细节完整
// ==============================================================
PixelShader =
{
    Samplers =
    {
        MapTexture =  // 主纹理（鹰与卍字标志的基础图像）
        {
            Index = 0  // 对应游戏传入的第0张图片（标志原图）
            MagFilter = "Linear"  // 放大时平滑过渡（避免符号边缘锯齿）
            MinFilter = "Linear"  // 缩小时平滑过渡
            MipFilter = "None"    // 不启用多级渐远纹理（标志无需远处模糊）
            AddressU = "Clamp"    // 超出范围时拉伸边缘（避免标志重复错位）
            AddressV = "Clamp"
            MipMapLodBias = -0.8  // 微调清晰度（增强标志细节，如纹理、纹路）
        }
        MaskTexture =  // 动画遮罩1（控制标志局部动画，如部分区域闪烁）
        {
            Index = 1  // 对应第1张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture =  // 动画纹理1（标志的动态效果，如发光、流动）
        {
            Index = 2  // 对应第2张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"  // 超出范围时重复（适合循环动画，如光效）
            AddressV = "Wrap"
        }
        MaskTexture2 =  // 动画遮罩2（备用遮罩，用于复杂动态分层）
        {
            Index = 3  // 对应第3张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture2 =  // 动画纹理2（第二套动态效果，如颜色渐变）
        {
            Index = 4  // 对应第4张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"
            AddressV = "Wrap"
        }
        // 主遮罩（控制标志的整体可见形状，如仅显示标志轮廓）
        MaskingTexture =
        {
            Index = 5  // 对应第5张图片
            MagFilter = "Point"  // 点过滤（保留标志边缘锐度，避免模糊）
            MinFilter = "Point"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
    }
}


// ==============================================================
// 顶点输出结构（VS_OUTPUT）：顶点着色器传递给像素着色器的数据
// 包含位置、纹理坐标，支持条件编译的动画/遮罩坐标（适配标志动态）
// ==============================================================
VertexStruct VS_OUTPUT
{
    float4  vPosition : PDX_POSITION;  // 像素在屏幕上的最终位置
    float2  vTexCoord : TEXCOORD0;     // 主纹理坐标（读取标志的位置）
@ifdef ANIMATED  // 开启动画时，包含动画纹理坐标（如动态光效位置）
    float4  vAnimatedTexCoord : TEXCOORD1;
@endif
@ifdef MASKING  // 开启遮罩时，包含主遮罩坐标（控制标志显示范围）
    float2  vMaskingTexCoord : TEXCOORD2;
@endif
};


// ==============================================================
// 顶点着色器（VertexShader）：计算标志的位置和基础纹理坐标
// 结构简单，仅负责位置转换和纹理坐标传递（动态变换由像素着色器处理）
// ==============================================================
VertexShader =
{
    MainCode VertexShader
    [[
        VS_OUTPUT main(const VS_INPUT v )
        {
            VS_OUTPUT Out;
            // 计算屏幕位置：通过投影矩阵将3D坐标转为屏幕2D坐标
            Out.vPosition  = mul( WorldViewProjectionMatrix, float4( v.vPosition.xyz, 1 ) );
        
            // 传递主纹理坐标（告诉像素着色器该读取标志的哪个部分）
            Out.vTexCoord = v.vTexCoord;
        
            return Out;
        }
    ]]
}


// ==============================================================
// 像素着色器（PixelShader）：核心逻辑，控制标志的动态变换
// 重点：Up/Disable状态通过纹理坐标变换实现"展开+位移"动画，时间窗口精确
// ==============================================================
PixelShader =
{
    // 1. 状态：Up（正常显示状态，标志的标准出现动画）
    MainCode PixelShaderUp
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 计算动画时间：当前时间(Time) - 动画开始时间(AnimationTime)
            float vTime = Time - AnimationTime;
            
            // 【控制参数1：Offset.x】强制隐藏开关
            // 若Offset.x的整数部分+1等于2，则标志完全透明（不显示）
            float value = floor(Offset.x) + 1.f;  // floor取整数部分（如1.6→1）
            if(value == 2)
            {
                return float4(0,0,0,0);  // 全透明（隐藏）
            }
            
            // 本地时间：相对于26秒的偏移（动画从26秒开始计算）
            float fTime = vTime - 26.f;
            float2 newTexCoord = v.vTexCoord;  // 变换后的纹理坐标（用于动态效果）
            float2 imgTexCoord = v.vTexCoord;  // 原始纹理坐标（用于混合）
            // 读取标志主纹理颜色（初始颜色）
            float4 OutColor = tex2D( MapTexture, newTexCoord );
            
            // 时间窗口外（>34秒 或 <26秒）：标志完全透明（不显示）
            if(vTime > 34.f)
            {
                return float4(0,0,0,0);
            }
            if(vTime < 26)
            {
                return float4(0,0,0,0);
            }
            
            // 阶段1：26~26.25秒（0.25秒窗口）→ 标志横向缩放展开
            if(fTime < 0.25f)
            {
                // X方向围绕中心（0.5, y）缩放：
                newTexCoord.x -= 0.5f;  // 坐标原点移到X方向中心（0.5）
                // 缩放因子：sin(fTime * 6) → 从sin(0)=0快速增至sin(1.5)=≈0.997（接近1）
                // 除以缩放因子 → 初始缩放极大（因sin接近0），快速收缩到正常大小（展开效果）
                newTexCoord.x /= sin(fTime * 6.f);
                newTexCoord.x += 0.5f;  // 坐标原点移回原位置
                
                // 限制显示区域：仅Y坐标>0.835的部分可见（标志的上半部分先出现）
                if(v.vTexCoord.y < 0.835)
                {
                    return float4(0,0,0,0);
                }
                // 用变换后的坐标读取纹理（横向展开效果）
                OutColor = tex2D( MapTexture, newTexCoord );
                return OutColor;
            }
            // 阶段2：26.25~27秒（0.75秒窗口）→ 标志纵向位移+上下部分混合
            else if(fTime >= 0.25 && fTime < 1)
            {
                // Y方向位移：基于sin函数的波动（0.89316为位移幅度系数）
                // (0.75 - (fTime-0.25)) → 时间从0.75→0，sin值从sin(0.75*2)=≈sin(1.5)=0.997→sin(0)=0
                // 整体效果：标志纵向先上移再回落（轻微波动）
                imgTexCoord.y -= (0.89316 * sin((0.75f - (fTime - 0.25f)))*2.f);
            }
            
            // 读取变换后的颜色（阶段2的基础颜色）
            OutColor = tex2D( MapTexture, newTexCoord );
            // 限制显示区域：仅Y坐标>0.837的部分可见（微调显示范围）
            if(newTexCoord.y < 0.837)
            {
                OutColor = float4(0,0,0,0);
            }
            
            // 读取原始坐标的颜色（用于混合的另一部分）
            float4 imgColour = tex2D( MapTexture, imgTexCoord );
            // 限制混合区域：仅Y坐标<0.835且<0.89316的部分参与混合（标志的下半部分）
            if(imgTexCoord.y >= 0.835 || v.vTexCoord.y >= 0.89316)
            {
                imgColour = float4(0,0,0,0);
            }
            
            // 阶段2：混合上下两部分颜色（实现平滑过渡）
            if(fTime >= 0.25 && fTime < 1)
            {
                float4 finalColour = float4(0,0,0,0);  // 最终混合色
                // 计算最终透明度：1 - (1-上部分透明度)*(1-下部分透明度)（叠加透明度）
                finalColour.a = 1.f - (1.f - OutColor.a) * (1.f - imgColour.a);
                // 计算最终RGB：上部分颜色与下部分颜色按透明度比例混合
                finalColour.r = (imgColour.r * imgColour.a + OutColor.r * OutColor.a * (1 - imgColour.a)) / finalColour.a;
                finalColour.g = (imgColour.g * imgColour.a + OutColor.g * OutColor.a * (1 - imgColour.a)) / finalColour.a;
                finalColour.b = (imgColour.b * imgColour.a + OutColor.b * OutColor.a * (1 - imgColour.a)) / finalColour.a;
                return finalColour;
            }
            
            // 阶段3：27~34秒 → 显示正常标志颜色
            float4 normal = tex2D( MapTexture, v.vTexCoord );
            return normal;
        }
    ]]

    // 2. 状态：Down（按下状态，标志变暗效果）
    MainCode PixelShaderDown
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取标志主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                    
        // 开启动画时，混合动画纹理（如按下时标志局部变暗闪烁）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度（如仅显示标志核心部分）
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;  // 遮罩透明区域让对应部分消失
        #endif
            
            // 用游戏传入的Color参数调整标志色调（按下时整体变暗）
            OutColor *= Color;

            // 按下时的亮度衰减（随时间变暗，保持标志质感）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 16 );  // 限制值0~1
            vTime *= vTime;  // 平方运算让变化更平滑（先快后慢）
            vTime = 0.9*0.9 - vTime;  // 反向计算衰减值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（降低亮度）
            OutColor.rgb -= ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 降低RGB亮度

            return OutColor;
        }
    ]]

    // 3. 状态：Disable（禁用状态，标志的延迟变换动画）
    MainCode PixelShaderDisable
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 计算动画时间：当前时间 - 动画开始时间
            float vTime = Time - AnimationTime;

            // 【控制参数：Offset.x】强制隐藏（同Up状态）
            float value = floor(Offset.x) + 1.f;
            if(value == 2)
            {
                return float4(0,0,0,0);
            }

            // 本地时间：相对于26.5秒的偏移（比Up状态晚0.5秒开始）
            float fTime = vTime - 26.5f;
            float2 newTexCoord = v.vTexCoord;  // 变换后的纹理坐标
            float2 imgTexCoord = v.vTexCoord;  // 原始纹理坐标（用于混合）
            float4 OutColor = tex2D( MapTexture, newTexCoord );  // 初始颜色
            
            // 时间窗口外（>34秒 或 <26.5秒）：标志完全透明（不显示）
            if(vTime > 34.f)
            {
                return float4(0,0,0,0);
            }
            if(vTime < 26.5f)
            {
                return float4(0,0,0,0);
            }
            // 阶段1：26.5~26.75秒（0.25秒窗口）→ 横向缩放展开（参数微调）
            else if(fTime < 0.25f)
            {
                // X方向围绕中心缩放（同Up状态逻辑，实现展开效果）
                newTexCoord.x -= 0.5f;
                newTexCoord.x /= sin(fTime * 6.f);
                newTexCoord.x += 0.5f;
                
                // 限制显示区域：仅Y坐标>0.801的部分可见（比Up状态的0.835低，显示范围稍大）
                if(v.vTexCoord.y < 0.801)
                {
                    return float4(0,0,0,0);
                }
                OutColor = tex2D( MapTexture, newTexCoord );
                return OutColor;
            }
            // 阶段2：26.75~27.5秒（0.75秒窗口）→ 纵向位移+混合（参数微调）
            else if(fTime >= 0.25 && fTime < 1.f)
            {
                // Y方向位移：幅度系数为0.858（比Up状态的0.89316小，位移更平缓）
                imgTexCoord.y -= (0.858 * sin((0.75f - (fTime - 0.25f)))*2.f);
            }
            
            // 读取变换后的颜色
            OutColor = tex2D( MapTexture, newTexCoord );
            // 限制显示区域：仅Y坐标>0.801的部分可见
            if(newTexCoord.y < 0.801)
            {
                OutColor = float4(0,0,0,0);
            }
            
            // 读取原始坐标的颜色（用于混合）
            float4 imgColour = tex2D( MapTexture, imgTexCoord );
            // 限制混合区域：仅Y坐标<0.801且<0.858的部分参与混合
            if(imgTexCoord.y >= 0.801 || v.vTexCoord.y >= 0.858)
            {
                imgColour = float4(0,0,0,0);
            }
            
            // 阶段2：混合上下两部分颜色（同Up状态逻辑，实现平滑过渡）
            if(fTime >= 0.25f && fTime < 1.f)
            {
                float4 finalColour = float4(0,0,0,0);
                finalColour.a = 1.f - (1.f - OutColor.a) * (1.f - imgColour.a);
                finalColour.r = (imgColour.r * imgColour.a + OutColor.r * OutColor.a * (1 - imgColour.a)) / finalColour.a;
                finalColour.g = (imgColour.g * imgColour.a + OutColor.g * OutColor.a * (1 - imgColour.a)) / finalColour.a;
                finalColour.b = (imgColour.b * imgColour.a + OutColor.b * OutColor.a * (1 - imgColour.a)) / finalColour.a;
                return finalColour;
            }
            
            // 阶段3：27.5~34秒 → 显示正常标志颜色
            float4 normal = tex2D( MapTexture, v.vTexCoord );
            return normal;
        }	
    ]]

    // 4. 状态：Over（悬停状态，标志变亮效果）
    MainCode PixelShaderOver
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取标志主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                
        // 开启动画时，混合动画纹理（如悬停时标志边缘发光）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;
        #endif

            // 用Color参数调整标志色调（悬停时整体变亮）
            OutColor *= Color;
            
            // 悬停时的亮度增强（随时间变亮，突出标志）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 4 );  // 变化较慢（系数4）
            vTime *= vTime;  // 平方运算让变化平滑
            vTime = 0.9*0.9 - vTime;  // 反向计算增强值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（提升亮度）
            OutColor.rgb += ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 增加RGB亮度

            return OutColor;
        }
    ]]
}


// ==============================================================
// 混合状态（BlendState）：控制标志与下层元素的叠加方式
// 启用混合确保标志的半透明区域（如边缘、细节）正确叠加，不突兀
// ==============================================================
BlendState BlendState
{
    BlendEnable = yes  // 启用混合（支持标志半透明效果）
    SourceBlend = "src_alpha"  // 自身颜色占比=自身透明度
    DestBlend = "inv_src_alpha"  // 下层颜色占比=1-自身透明度
    // 最终颜色 = 标志颜色*透明度 + 下层颜色*(1-透明度)（确保标志与背景自然融合）
}


// ==============================================================
// 效果定义（Effect）：组合顶点和像素着色器，供游戏调用
// 游戏根据标志的状态（正常/按下/禁用/悬停）自动切换
// ==============================================================
Effect Up  // 正常状态：26~34秒，横向展开→纵向位移→正常显示
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderUp"
}

Effect Down  // 按下状态：标志变暗
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDown"
}

Effect Disable  // 禁用状态：26.5~34秒，延迟展开→平缓位移→正常显示
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDisable"
}

Effect Over  // 悬停状态：标志变亮
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderOver"
}