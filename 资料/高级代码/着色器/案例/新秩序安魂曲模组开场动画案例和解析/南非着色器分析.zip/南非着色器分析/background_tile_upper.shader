// ==============================================================
// 文件名：background_tile_upper.shader
// 作用：控制钢铁雄心 4 中 "上层背景瓦片" 的显示效果和动态动画
// 适用场景：覆盖在下层背景瓦片之上的装饰性元素（如边框纹理、标识图案、局部装饰），增强背景层次感
// 核心功能：在与下层瓦片同步的时间窗口（0~120.5 秒）内提供装饰性视觉支撑，包含：
// 			- 初始黑色渐显（0~2 秒，与下层同步入场，避免视觉断层）
// 			- 稳定展示（2~110.5 秒，约 108.5 秒作为装饰层，丰富背景细节）
// 			- 后期燃烧退场（110.5~120.5 秒，10 秒从角落向外燃烧消失，与下层形成对称效果）
// 			- 交互状态反馈（按下变暗、悬停变亮，适配用户操作）
// 与下层瓦片（background_tile_lower）的核心差异：
// 1. 功能定位：上层为装饰层（增加细节），下层为基础层（提供底色）；
// 2. 燃烧位置：Up 状态从左下角燃烧，Disable 状态从右下角燃烧，与下层的右上 / 左上形成对角对称，退场时形成整体视觉闭环；
// 3. 燃烧速度：稍快于下层（Speed=0.133>0.13），确保装饰元素先于基础层完成退场，避免残留感
// ==============================================================


// ==============================================================
// 引入外部工具包（复用通用功能）
// ==============================================================
Includes = {
    "buttonstate.fxh"      // 包含按钮状态（如按下、弹起）的通用逻辑
    "sprite_animation.fxh" // 包含精灵动画（序列帧、纹理动画）的通用函数
    "/intros/saf/burn.fxh" // 包含燃烧效果函数（从中心向外扩散的动画，已解释）
}


// ==============================================================
// 像素着色器采样器（Samplers）：定义读取图片（纹理）的规则
// 每个采样器对应游戏传入的一张图片，通过Index区分（与下层瓦片完全一致）
// ==============================================================
PixelShader =
{
    Samplers =
    {
        MapTexture =  // 主纹理采样器（上层背景的基础图片，如装饰元素原图）
        {
            Index = 0  // 对应游戏传入的第0张图片
            MagFilter = "Linear"  // 放大时线性过滤（平滑）
            MinFilter = "Linear"  // 缩小时线性过滤（平滑）
            MipFilter = "None"    // 关闭多级渐远纹理（无需远处模糊）
            AddressU = "Clamp"    // 水平方向超出范围时拉伸边缘（不重复）
            AddressV = "Clamp"    // 垂直方向超出范围时拉伸边缘
            MipMapLodBias = -0.8  // 微调纹理细节（轻微提升清晰度）
        }
        MaskTexture =  // 动画遮罩纹理1（控制动画显示区域，辅助序列帧）
        {
            Index = 1  // 对应游戏传入的第1张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture =  // 动画纹理1（动态序列帧，如闪烁、流动效果）
        {
            Index = 2  // 对应游戏传入的第2张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"  // 水平方向超出范围时重复（适合循环动画）
            AddressV = "Wrap"  // 垂直方向超出范围时重复
        }
        MaskTexture2 =  // 动画遮罩纹理2（备用遮罩，用于复杂分层动画）
        {
            Index = 3  // 对应游戏传入的第3张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture2 =  // 动画纹理2（备用序列帧，第二套动画效果）
        {
            Index = 4  // 对应游戏传入的第4张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"
            AddressV = "Wrap"
        }
        // 注意：这是控制整体可见区域的主遮罩（其他遮罩仅用于动画）
        MaskingTexture =  // 主遮罩纹理（如裁剪出特定形状，边缘清晰）
        {
            Index = 5  // 对应游戏传入的第5张图片
            MagFilter = "Point"  // 放大时点过滤（保留边缘清晰度）
            MinFilter = "Point"  // 缩小时点过滤
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
    }
}


// ==============================================================
// 顶点输出结构（VS_OUTPUT）：顶点着色器传递给像素着色器的数据
// 包含位置、纹理坐标，以及条件编译的动画/遮罩坐标（与下层瓦片一致）
// ==============================================================
VertexStruct VS_OUTPUT
{
    float4  vPosition : PDX_POSITION;  // 像素在屏幕上的最终位置
    float2  vTexCoord : TEXCOORD0;     // 主纹理坐标（读取基础图片的位置）
@ifdef ANIMATED  // 开启动画时，包含动画纹理坐标
    float4  vAnimatedTexCoord : TEXCOORD1;
@endif
@ifdef MASKING  // 开启遮罩时，包含主遮罩纹理坐标
    float2  vMaskingTexCoord : TEXCOORD2;
@endif
};


// ==============================================================
// 顶点着色器（VertexShader）：计算图片位置和基础纹理坐标
// 所有状态共用，逻辑与下层瓦片完全一致
// ==============================================================
VertexShader =
{
    MainCode VertexShader  // 顶点着色器主函数
    [[
        // 输入：原始顶点数据（未转换的位置、纹理坐标等）
        // 输出：处理后的顶点数据（位置+纹理坐标）
        VS_OUTPUT main(const VS_INPUT v )
        {
            VS_OUTPUT Out;
            
            // 计算屏幕位置：通过投影矩阵将3D坐标转换为屏幕2D坐标
            // WorldViewProjectionMatrix由游戏自动传入，负责位置转换
            Out.vPosition  = mul( WorldViewProjectionMatrix, float4( v.vPosition.xyz, 1 ) );
        
            // 传递主纹理坐标（告诉像素着色器该读图片的哪个点）
            Out.vTexCoord = v.vTexCoord;
        
            return Out;
        }
    ]]
}


// ==============================================================
// 像素着色器（PixelShader）：计算每个像素的最终颜色，实现状态动画
// 包含4个状态，核心差异在于Up和Disable的燃烧起始位置
// ==============================================================
PixelShader =
{
    // 1. 状态：Up（正常显示/向上触发状态）
    MainCode PixelShaderUp
    [[
        // 输入：顶点着色器输出的位置和纹理坐标
        // 输出：像素最终颜色（含透明度）
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取主纹理颜色（上层背景的基础色）
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            
            // 【控制参数1：Offset.x】游戏传入的偏移参数，用于触发隐藏
            // 计算Offset.x的整数部分+1，若等于2则完全透明（不显示）
            float value = floor(Offset.x) + 1.f;  // floor取整数部分（如2.3→2）
            if(value == 2)
            {
                return float4(0,0,0,0);  // 全透明（隐藏）
            }
            
            // 计算动画时间：当前时间(Time) - 动画开始时间(AnimationTime)
            // 【控制参数2：Time】游戏当前时间；【控制参数3：AnimationTime】动画开始时间
            float vTime = Time - AnimationTime;
            
            // 动画时间0~2秒：显示黑色并逐渐变亮（透明度从0→1，类似"淡入"）
            if(vTime < 2.f)
            {
                OutColor = float4(0,0,0,1);  // 黑色
                OutColor.a = vTime * 0.5f;   // 2秒时透明度=1（完全显示黑色）
            }
            // 动画时间110.5~120.5秒：显示从左下角开始的燃烧效果
            else if(vTime > 110.5f && vTime < 120.5f)
            {
                // 燃烧效果参数（调用burn.fxh中的ApplyBurnColour函数）
                float4 colour = float4(0,0,0,1);  // 燃烧的基础颜色（黑色）
                float2 BurnCenter = float2(0.f, 1.f);  // 燃烧中心（左下角：x=0最左，y=1最下）
                float Aspect = 1.0f;  // 宽高比（1.0=正方形，无拉伸）
                float cTime = vTime - 110.5f;  // 燃烧动画的本地时间（从0开始计时）
                float Radius0 = 0.0f;  // 初始燃烧半径（0=从点开始）
                float Speed = 0.133f;  // 燃烧扩展速度（比下层瓦片稍快，0.133>0.13）
                float JagAmp = 0.01f;  // 边缘锯齿幅度（轻微不规则）
                float Freq = 4.f;      // 锯齿频率（中等密度）
                float Flow = 0.8f;     // 锯齿流动速度（模拟火焰飘动）
                float EdgeWidth = 0.01f; // 燃烧边缘过渡宽度（较清晰）
                float RimWidth = 0.001f; // 光晕宽度（几乎无）
                float RimSigma = 0.005f; // 光晕模糊度（轻微模糊）
                float HeatAmp = 0.003f;  // 热扭曲幅度（轻微扭曲）
                float3 EmberColor = float3(0.8, 0.6, 0.4); // 火焰颜色（浅橙褐色）
                float EmberBoost = 0.05f; // 火焰亮度（较暗）
                
                // 调用燃烧效果函数，返回从左下角扩散的燃烧效果
                float4 burn = ApplyBurnColour(v.vTexCoord, colour, BurnCenter, Aspect, cTime, 
                                             Radius0, Speed, JagAmp, Freq, Flow, 
                                             EdgeWidth, RimWidth, RimSigma, HeatAmp, 
                                             EmberColor, EmberBoost);
                return burn;  // 显示燃烧效果
            }
            // 动画时间超过120.5秒：完全透明（隐藏）
            else if(vTime > 120.5f)
            {
                return float4(0,0,0,0);
            }
            
            // 其他时间：显示原始主纹理颜色
            return OutColor;
        }
    ]]

    // 2. 状态：Down（按下/向下触发状态）
    MainCode PixelShaderDown
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取主纹理颜色（基础背景色）
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                    
        // 开启动画时（定义ANIMATED宏），调用Animate函数混合动画纹理
        // Animate来自sprite_animation.fxh，用遮罩控制动画区域
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时（定义MASKING宏），用主遮罩控制透明度
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );  // 读取遮罩颜色
            OutColor.a *= MaskColor.a;  // 遮罩透明区域（a=0）让图片对应区域透明
        #endif
            
            // 【控制参数4：Color】游戏传入的整体色调（叠加颜色滤镜）
            OutColor *= Color;

            // 时间相关的亮度衰减（按下时变暗效果）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 16 );  // 限制值在0~1
            vTime *= vTime;  // 平方运算让变化更平滑（先快后慢）
            vTime = 0.9*0.9 - vTime;  // 反向计算，得到衰减的亮度值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（变暗用）
            OutColor.rgb -= ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 降低RGB亮度

            return OutColor;
        }
    ]]

    // 3. 状态：Disable（禁用状态，不可交互时的效果）
    MainCode PixelShaderDisable
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取主纹理颜色（基础背景色）
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            
            // 同Up状态：用Offset.x控制隐藏（值为2时不显示）
            float value = floor(Offset.x) + 1.f;
            if(value == 2)
            {
                return float4(0,0,0,0);
            }
            
            // 计算动画时间（当前时间 - 动画开始时间）
            float vTime = Time - AnimationTime;
            
            // 动画时间0~2秒：显示黑色并逐渐变亮（同Up状态的初始效果）
            if(vTime < 2.f)
            {
                OutColor = float4(0,0,0,1);
                OutColor.a = vTime * 0.5f;
            }
            // 动画时间110.5~120.5秒：显示从右下角开始的燃烧效果
            else if(vTime > 110.5f && vTime < 120.5f)
            {
                // 燃烧效果参数（与Up状态类似，仅燃烧中心不同）
                float4 colour = float4(0,0,0,1);  // 基础黑色
                float2 BurnCenter = float2(1.f, 1.f);  // 燃烧中心（右下角：x=1最右，y=1最下）
                float Aspect = 1.0f;  // 宽高比
                float cTime = vTime - 110.5f;  // 燃烧本地时间
                float Radius0 = 0.0f;  // 初始半径
                float Speed = 0.133f;  // 扩展速度（与Up状态相同，稍快于下层）
                float JagAmp = 0.01f;  // 锯齿幅度
                float Freq = 4.f;      // 锯齿频率
                float Flow = 0.8f;     // 流动速度
                float EdgeWidth = 0.01f; // 边缘宽度
                float RimWidth = 0.001f; // 光晕宽度
                float RimSigma = 0.005f; // 光晕模糊度
                float HeatAmp = 0.003f;  // 热扭曲幅度
                float3 EmberColor = float3(0.8, 0.6, 0.4); // 火焰颜色
                float EmberBoost = 0.05f; // 火焰亮度
                
                // 调用燃烧效果函数，返回从右下角扩散的燃烧效果
                float4 burn = ApplyBurnColour(v.vTexCoord, colour, BurnCenter, Aspect, cTime, 
                                             Radius0, Speed, JagAmp, Freq, Flow, 
                                             EdgeWidth, RimWidth, RimSigma, HeatAmp, 
                                             EmberColor, EmberBoost);
                return burn;
            }
            // 动画时间超过120.5秒：完全透明（隐藏）
            else if(vTime > 120.5f)
            {
                return float4(0,0,0,0);
            }
            
            // 其他时间：显示原始主纹理颜色
            return OutColor;
        }	
    ]]

    // 4. 状态：Over（悬停状态，鼠标移过时的效果）
    MainCode PixelShaderOver
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取主纹理颜色（基础背景色）
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                
        // 开启动画时，调用Animate函数混合动画纹理（同Down状态）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度（同Down状态）
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;
        #endif

            // 用Color参数调整整体色调
            OutColor *= Color;
            
            // 时间相关的亮度增强（悬停时变亮效果）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 4 );  // 变化较慢（乘4）
            vTime *= vTime;  // 平方运算让变化平滑
            vTime = 0.9*0.9 - vTime;  // 反向计算，得到增强的亮度值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（变亮用）
            OutColor.rgb += ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 增加RGB亮度

            return OutColor;
        }
    ]]
}


// ==============================================================
// 混合状态（BlendState）：控制图片与背景的叠加方式（透明效果）
// 与下层瓦片完全一致，确保上下层透明区域正确叠加
// ==============================================================
BlendState BlendState
{
    BlendEnable = yes  // 启用混合（支持透明）
    SourceBlend = "src_alpha"  // 自身颜色占比=自身透明度
    DestBlend = "inv_src_alpha"  // 背景颜色占比=1-自身透明度
    // 最终颜色 = 自身颜色*透明度 + 背景颜色*(1-透明度)
    // 例：半透明像素（a=0.5）会混合50%自身和50%背景
}


// ==============================================================
// 效果定义（Effect）：组合顶点和像素着色器，供游戏调用
// 游戏根据上层背景元素的状态（如悬停、禁用）自动切换
// ==============================================================
Effect Up  // Up状态：顶点着色器 + PixelShaderUp（左下角燃烧）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderUp"
}

Effect Down  // Down状态：顶点着色器 + PixelShaderDown（变暗）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDown"
}

Effect Disable  // Disable状态：顶点着色器 + PixelShaderDisable（右下角燃烧）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDisable"
}

Effect Over  // Over状态：顶点着色器 + PixelShaderOver（变亮）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderOver"
}