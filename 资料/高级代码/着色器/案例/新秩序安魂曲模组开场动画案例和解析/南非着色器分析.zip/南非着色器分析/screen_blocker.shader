// ==============================================================
// 文件名：screen_blocker.shader
// 作用：控制钢铁雄心4中"屏幕遮挡元素"的显示效果和动态动画
// 适用场景：游戏中的过渡效果、场景切换遮罩、瞬间闪光遮挡（如剧情转折、事件触发时的屏幕特效）
// 核心功能：仅在特定时间点（88~88.6秒）显示短暂的扩散式闪光遮挡，其他状态下隐藏或提供交互反馈，包含：
//          - 正常状态（Up）：完全隐藏
//          - 禁用状态（Disable）：88~88.6秒的白色扩散闪光（从上到下覆盖屏幕）
//          - 按下/悬停状态：基础亮度调整（保持交互逻辑一致性）
// 与其他元素的差异：作为瞬时过渡特效，存续时间极短（仅0.6秒），用于强化关键时间点的视觉冲击
// ==============================================================


// ==============================================================
// 引入外部工具包（复用核心功能）
// 包含按钮状态、动画工具和燃烧效果（虽未直接使用燃烧，为扩展预留）
// ==============================================================
Includes = {
    "buttonstate.fxh"        // 按钮状态逻辑（按下/悬停判断）
    "sprite_animation.fxh"   // 精灵动画函数（支持基础动态效果）
    "/intros/saf/burn.fxh"   // 燃烧效果工具（预留，可扩展为其他过渡效果）
}


// ==============================================================
// 像素着色器采样器（Samplers）：定义纹理读取规则
// 虽包含多个纹理配置，但核心遮挡效果为纯色闪光，纹理主要用于交互状态
// ==============================================================
PixelShader =
{
    Samplers =
    {
        MapTexture =  // 主纹理（遮挡元素的基础图像，交互状态下使用）
        {
            Index = 0  // 对应游戏传入的第0张图片
            MagFilter = "Linear"  // 放大时平滑过渡（避免边缘锯齿）
            MinFilter = "Linear"  // 缩小时平滑过渡
            MipFilter = "None"    // 不启用多级渐远纹理（遮挡效果无需模糊）
            AddressU = "Clamp"    // 超出范围时拉伸边缘（避免重复）
            AddressV = "Clamp"
            MipMapLodBias = -0.8  // 微调清晰度（增强纹理细节）
        }
        MaskTexture =  // 动画遮罩1（交互状态下的局部动态控制）
        {
            Index = 1  // 对应第1张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture =  // 动画纹理1（交互状态下的动态效果）
        {
            Index = 2  // 对应第2张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"  // 超出范围时重复（适合循环动画）
            AddressV = "Wrap"
        }
        MaskTexture2 =  // 动画遮罩2（备用遮罩，复杂动态分层）
        {
            Index = 3  // 对应第3张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture2 =  // 动画纹理2（第二套动态效果）
        {
            Index = 4  // 对应第4张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"
            AddressV = "Wrap"
        }
        // 主遮罩（控制遮挡元素的可见形状，确保边缘精确）
        MaskingTexture =
        {
            Index = 5  // 对应第5张图片
            MagFilter = "Point"  // 点过滤（保留边缘锐度，避免模糊）
            MinFilter = "Point"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
    }
}


// ==============================================================
// 顶点输出结构（VS_OUTPUT）：顶点着色器传递给像素着色器的数据
// 包含位置、纹理坐标，支持动画/遮罩坐标（适配交互状态的动态）
// ==============================================================
VertexStruct VS_OUTPUT
{
    float4  vPosition : PDX_POSITION;  // 像素在屏幕上的最终位置
    float2  vTexCoord : TEXCOORD0;     // 主纹理坐标（读取纹理位置）
@ifdef ANIMATED  // 开启动画时，包含动画纹理坐标
    float4  vAnimatedTexCoord : TEXCOORD1;
@endif
@ifdef MASKING  // 开启遮罩时，包含主遮罩坐标
    float2  vMaskingTexCoord : TEXCOORD2;
@endif
};


// ==============================================================
// 顶点着色器（VertexShader）：计算遮挡元素的位置和纹理坐标
// 结构简单，仅负责基础位置转换和坐标传递（核心动态在像素着色器）
// ==============================================================
VertexShader =
{
    MainCode VertexShader
    [[
        VS_OUTPUT main(const VS_INPUT v )
        {
            VS_OUTPUT Out;
            // 计算屏幕位置：通过投影矩阵将3D坐标转为屏幕2D坐标
            Out.vPosition  = mul( WorldViewProjectionMatrix, float4( v.vPosition.xyz, 1 ) );
        
            // 传递主纹理坐标（告诉像素着色器读取纹理的哪个部分）
            Out.vTexCoord = v.vTexCoord;
        
            return Out;
        }
    ]]
}


// ==============================================================
// 像素着色器（PixelShader）：核心逻辑，控制遮挡效果的触发与消失
// 重点：仅在Disable状态的88~88.6秒显示短暂闪光，其他状态几乎隐藏
// ==============================================================
PixelShader =
{
    // 1. 状态：Up（正常状态，完全隐藏）
    MainCode PixelShaderUp
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 直接返回全透明（0,0,0,0），正常状态下不显示任何遮挡
            return float4(0,0,0,0);
        }
    ]]

    // 2. 状态：Down（按下状态，基础交互反馈）
    MainCode PixelShaderDown
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取主纹理颜色（交互状态下使用）
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                    
        // 开启动画时，混合动画纹理（增强按下时的动态反馈）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度（限制显示范围）
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;
        #endif
            
            // 用Color参数调整色调（按下时整体变暗）
            OutColor *= Color;

            // 亮度衰减计算（随时间变暗，强化按下的反馈感）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 16 );  // 限制值0~1
            vTime *= vTime;  // 平方运算让变化更平滑（先快后慢）
            vTime = 0.9*0.9 - vTime;  // 反向计算衰减值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（降低亮度）
            OutColor.rgb -= ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 降低RGB亮度

            return OutColor;
        }
    ]]

    // 3. 状态：Disable（禁用状态，核心遮挡效果：88~88.6秒的白色扩散闪光）
    MainCode PixelShaderDisable
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取主纹理颜色（基础颜色，实际遮挡效果为纯色）
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            // 计算动画时间：当前时间 - 动画开始时间
            float vTime = Time - AnimationTime;
            
            // 【控制参数：Offset.x】强制隐藏开关
            // 若Offset.x的整数部分+1等于2，则完全透明（不显示）
            float value = floor(Offset.x) + 1.f;
            if(value == 2)
            {
                return float4(0,0,0,0);
            }
            
            // 阶段1：<88秒 → 完全透明（不显示，等待触发时机）
            if(vTime < 88)
            {
                return float4(0,0,0,0);
            }
            // 阶段2：88~88.375秒（0.375秒窗口）→ 第一阶段扩散闪光（从上往下）
            else if(vTime >= 88 && vTime < 88.375)
            {
                float2 centre = float2(0.5, 0);  // 闪光中心（屏幕顶部中间，y=0为顶部）
                float4 colour = float4(0.9, 0.9, 0.9, 1);  // 闪光颜色（近白色，带轻微灰度）
                
                // 计算闪光半径（基于双重cos函数，实现加速扩散效果）
                // cos函数特性：从1→-1→1，通过嵌套让半径先慢后快扩散
                float radius = 1.f - cos((1.f - (cos((vTime - 88) * 4.f))) * 4.f);
                
                // 计算当前像素到中心的距离（基于纹理坐标，模拟屏幕空间距离）
                float distToCentre = sqrt(
                    (v.vTexCoord.x - 0.5f) * (v.vTexCoord.x - 0.5f) +  // x方向距离平方
                    (v.vTexCoord.y * v.vTexCoord.y)  // y方向距离平方（y=0为中心，向下递增）
                );
                
                // 距离小于半径：显示不透明闪光
                if(distToCentre < radius)
                {
                    return colour;
                }
                // 距离在半径~半径+0.05之间：边缘渐变透明（让闪光边缘柔和）
                else if(distToCentre > radius && distToCentre < radius + 0.05)
                {
                    float alpha = 1.f - ((distToCentre - radius)/0.05f);  // 透明度从1→0渐变
                    colour.a = alpha;
                    return colour;
                }
            }
            // 阶段3：88.375~88.6秒（0.225秒窗口）→ 第二阶段扩散闪光（加速覆盖）
            else if(vTime >= 88.375 && vTime < 88.6)
            {
                float2 centre = float2(0.5, 0);  // 同阶段2，保持中心在顶部中间
                float4 colour = float4(0.9, 0.9, 0.9, 1);  // 相同闪光颜色
                
                // 半径计算：调整系数（6.f）让扩散速度更快，覆盖范围更大
                float radius = 1.f - (1.f - cos((1.f - (cos((vTime - 88.375) * 6.f))) * 6.f));
                
                // 计算到中心的距离（同阶段2）
                float distToCentre = sqrt(
                    (v.vTexCoord.x - 0.5f) * (v.vTexCoord.x - 0.5f) + 
                    (v.vTexCoord.y * v.vTexCoord.y)
                );
                
                // 距离小于半径：显示闪光
                if(distToCentre < radius)
                {
                    return colour;
                }
                // 边缘渐变透明（同阶段2，保持柔和过渡）
                else if(distToCentre > radius && distToCentre < radius + 0.05)
                {
                    float alpha = 1.f - ((distToCentre - radius)/0.05f);
                    colour.a = alpha;
                    return colour;
                }
            }
            // 阶段4：≥88.6秒 → 完全透明（闪光结束，停止遮挡）
            return float4(0,0,0,0);
        }	
    ]]

    // 4. 状态：Over（悬停状态，基础交互反馈）
    MainCode PixelShaderOver
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取主纹理颜色（交互状态下使用）
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                
        // 开启动画时，混合动画纹理（增强悬停时的动态反馈）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;
        #endif

            // 用Color参数调整色调（悬停时整体变亮）
            OutColor *= Color;
            
            // 亮度增强计算（随时间变亮，突出悬停反馈）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 4 );  // 变化较慢（系数4）
            vTime *= vTime;  // 平方运算让变化平滑
            vTime = 0.9*0.9 - vTime;  // 反向计算增强值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（提升亮度）
            OutColor.rgb += ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 增加RGB亮度

            return OutColor;
        }
    ]]
}


// ==============================================================
// 混合状态（BlendState）：控制遮挡效果与屏幕内容的叠加方式
// 启用混合确保闪光边缘的半透明区域自然过渡，不生硬遮挡
// ==============================================================
BlendState BlendState
{
    BlendEnable = yes  // 启用混合（支持闪光边缘的半透明效果）
    SourceBlend = "src_alpha"  // 自身颜色占比=自身透明度
    DestBlend = "inv_src_alpha"  // 下层颜色占比=1-自身透明度
    // 最终颜色 = 闪光颜色*透明度 + 屏幕内容*(1-透明度)（确保闪光柔和覆盖）
}


// ==============================================================
// 效果定义（Effect）：组合顶点和像素着色器，供游戏调用
// 游戏根据遮挡元素的状态（正常/按下/禁用/悬停）自动切换
// ==============================================================
Effect Up  // 正常状态：完全隐藏（无遮挡）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderUp"
}

Effect Down  // 按下状态：纹理变暗（交互反馈）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDown"
}

Effect Disable  // 禁用状态：88~88.6秒触发白色扩散闪光（核心遮挡效果）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDisable"
}

Effect Over  // 悬停状态：纹理变亮（交互反馈）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderOver"
}