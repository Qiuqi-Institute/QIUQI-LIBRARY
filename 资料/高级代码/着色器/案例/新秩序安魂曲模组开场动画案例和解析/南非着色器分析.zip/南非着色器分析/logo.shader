// ==============================================================
// 文件名：logo.shader
// 作用：控制钢铁雄心4中"Logo元素"的显示效果和动态动画
// 适用场景：游戏中的标志性Logo（如游戏标题、开发商标识、版本信息等）
// 核心功能：根据状态和时间呈现Logo的缩放+淡入淡出动画，包含：
//          - 正常状态下的定时出现（106.5~116.5秒）、缓慢缩放+渐显渐隐
//          - 禁用状态下的灰度处理（但实际不显示）
//          - 按下/悬停时的亮度变化（保持交互反馈一致性）
// 与其他元素的差异：作为后期出现的标识，时间窗口晚于边框和标志，动画聚焦"平稳展示"
// ==============================================================


// ==============================================================
// 引入外部工具包（复用通用功能）
// 无需燃烧效果，核心是基础状态判断和简单动画
// ==============================================================
Includes = {
    "buttonstate.fxh"      // 按钮状态逻辑（按下/悬停判断）
    "sprite_animation.fxh" // 精灵动画函数（支持Logo的简单动态）
}


// ==============================================================
// 像素着色器采样器（Samplers）：定义纹理读取规则
// 针对Logo优化，确保标识清晰、边缘平滑（尤其缩放时）
// ==============================================================
PixelShader =
{
    Samplers =
    {
        MapTexture =  // 主纹理（Logo的基础图像，如游戏标题文字、图标）
        {
            Index = 0  // 对应游戏传入的第0张图片（Logo原图）
            MagFilter = "Linear"  // 放大时平滑过渡（避免缩放时边缘锯齿）
            MinFilter = "Linear"  // 缩小时平滑过渡
            MipFilter = "None"    // 不启用多级渐远纹理（Logo无需远处模糊）
            AddressU = "Clamp"    // 超出范围时拉伸边缘（避免Logo重复错位）
            AddressV = "Clamp"
            MipMapLodBias = -0.8  // 微调清晰度（增强Logo细节，如文字边缘）
        }
        MaskTexture =  // 动画遮罩1（控制Logo局部动态，如部分区域闪烁）
        {
            Index = 1  // 对应第1张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture =  // 动画纹理1（Logo的动态效果，如边缘发光）
        {
            Index = 2  // 对应第2张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"  // 超出范围时重复（适合循环动画，如光效流动）
            AddressV = "Wrap"
        }
        MaskTexture2 =  // 动画遮罩2（备用遮罩，用于复杂动态分层）
        {
            Index = 3  // 对应第3张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture2 =  // 动画纹理2（第二套动态效果，如颜色渐变）
        {
            Index = 4  // 对应第4张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"
            AddressV = "Wrap"
        }
        // 主遮罩（控制Logo的整体可见形状，如仅显示Logo轮廓）
        MaskingTexture =
        {
            Index = 5  // 对应第5张图片
            MagFilter = "Point"  // 点过滤（保留Logo边缘锐度，避免模糊）
            MinFilter = "Point"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
    }
}


// ==============================================================
// 顶点输出结构（VS_OUTPUT）：顶点着色器传递给像素着色器的数据
// 包含位置、纹理坐标，支持条件编译的动画/遮罩坐标（适配Logo动态）
// ==============================================================
VertexStruct VS_OUTPUT
{
    float4  vPosition : PDX_POSITION;  // 像素在屏幕上的最终位置
    float2  vTexCoord : TEXCOORD0;     // 主纹理坐标（读取Logo的位置）
@ifdef ANIMATED  // 开启动画时，包含动画纹理坐标（如动态光效位置）
    float4  vAnimatedTexCoord : TEXCOORD1;
@endif
@ifdef MASKING  // 开启遮罩时，包含主遮罩坐标（控制Logo显示范围）
    float2  vMaskingTexCoord : TEXCOORD2;
@endif
};


// ==============================================================
// 顶点着色器（VertexShader）：计算Logo的位置和基础纹理坐标
// 结构简单，仅负责位置转换和纹理坐标传递（缩放动画由像素着色器处理）
// ==============================================================
VertexShader =
{
    MainCode VertexShader
    [[
        VS_OUTPUT main(const VS_INPUT v )
        {
            VS_OUTPUT Out;
            // 计算屏幕位置：通过投影矩阵将3D坐标转为屏幕2D坐标
            Out.vPosition  = mul( WorldViewProjectionMatrix, float4( v.vPosition.xyz, 1 ) );
        
            // 传递主纹理坐标（告诉像素着色器该读取Logo的哪个部分）
            Out.vTexCoord = v.vTexCoord;
        
            return Out;
        }
    ]]
}


// ==============================================================
// 像素着色器（PixelShader）：核心逻辑，控制Logo的动态显示
// 重点：Up状态有严格的晚周期时间窗口，通过缩放+淡入淡出实现平稳展示
// ==============================================================
PixelShader =
{
    // 1. 状态：Up（正常显示状态，Logo的定时出现与缩放动画）
    MainCode PixelShaderUp
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 计算动画时间：当前时间(Time) - 动画开始时间(AnimationTime)
            float vTime = Time - AnimationTime;
            
            // 【控制参数1：Offset.x】强制隐藏开关
            // 若Offset.x的整数部分+1等于2，则Logo完全透明（不显示）
            float value = floor(Offset.x) + 1.f;  // floor取整数部分（如1.2→1）
            if(value == 2)
            {
                return float4(0,0,0,0);  // 全透明（隐藏）
            }
            
            // 计算缩放系数：从0.9开始，随时间缓慢增大（10秒内从0.9→1.0）
            // (vTime-106.5)/100 → 将10秒（116.5-106.5）映射到0~0.1，故size=0.9~1.0
            float size = 0.9f + ((vTime-106.5)/100.f);
            // 计算变换后的纹理坐标（以中心(0.5,0.5)为原点缩放）
            float2 newTexCoord = v.vTexCoord;
            newTexCoord -= 0.5;  // 坐标原点移到中心（0.5,0.5）
            newTexCoord /= size;  // 除以缩放系数（size>1则缩小，size增大→缩放程度减小）
            newTexCoord += 0.5;  // 坐标原点移回原位置
            
            // 读取缩放后的Logo颜色
            float4 OutColor = tex2D( MapTexture, newTexCoord );
            
            // 限制显示范围：仅纹理坐标在[0,1]内的部分可见（超出范围的区域隐藏）
            if(newTexCoord.x < 0 || newTexCoord.x > 1 || newTexCoord.y < 0 || newTexCoord.y > 1)
            {
                return float4(0,0,0,0);
            }
            
            // 时间窗口外（<106.5秒 或 >116.5秒）：Logo完全透明（不显示）
            // 注意：此时间远晚于边框（12~34秒）和标志（26~34秒），属于后期展示
            if(vTime < 106.5f || vTime > 116.5f)
            {
                return float4(0,0,0,0);
            }
            // 阶段1：106.5~108.5秒（2秒窗口）→ 渐入（透明度从0→1）
            else if(vTime >= 106.5f && vTime < 108.5f)
            {
                OutColor.a *= (vTime - 106.5f) * 0.5f;  // 106.5秒0→108.5秒1（线性递增）
            }
            // 阶段3：114.5~116.5秒（2秒窗口）→ 渐出（透明度从1→0）
            else if(vTime >= 114.5f && vTime < 116.5f)
            {
                OutColor.a *= 1.f - ((vTime - 114.5f) * 0.5f);  // 114.5秒1→116.5秒0（线性递减）
            }
            // 阶段2：108.5~114.5秒（6秒窗口）→ 完全显示（透明度保持1）
            
            return OutColor;
        }
    ]]

    // 2. 状态：Down（按下状态，Logo变暗效果）
    MainCode PixelShaderDown
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取Logo主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                    
        // 开启动画时，混合动画纹理（如按下时Logo局部变暗）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度（如仅显示Logo核心部分）
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;  // 遮罩透明区域让对应部分消失
        #endif
            
            // 用游戏传入的Color参数调整Logo色调（按下时整体变暗）
            OutColor *= Color;

            // 按下时的亮度衰减（随时间变暗，保持交互反馈）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 16 );  // 限制值0~1
            vTime *= vTime;  // 平方运算让变化更平滑（先快后慢）
            vTime = 0.9*0.9 - vTime;  // 反向计算衰减值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（降低亮度）
            OutColor.rgb -= ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 降低RGB亮度

            return OutColor;
        }
    ]]

    // 3. 状态：Disable（禁用状态，Logo的灰度处理与隐藏）
    MainCode PixelShaderDisable
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取Logo主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            
            // 【控制参数：Offset.x】强制隐藏（同Up状态）
            float value = floor(Offset.x) + 1.f;
            if(value == 2)
            {
                return float4(0,0,0,0);
            }
            
            // 将Logo颜色转为灰度（计算亮度值，R/G/B通道统一为亮度）
            // 公式：Grey = 0.212671*R + 0.715160*G + 0.072169*B（标准亮度计算）
            float Grey = dot( OutColor.rgb, float3( 0.212671f, 0.715160f, 0.072169f ) ); 
            OutColor.rgb = float3(Grey, Grey, Grey);  // 灰度化处理

        // 开启遮罩时，用主遮罩控制透明度
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;
        #endif

            // 用Color参数调整灰度色调（但实际下面直接返回透明）
            OutColor *= Color;
            // 最终返回全透明（禁用状态下Logo不显示，灰度处理仅为潜在备用）
            return float4(0,0,0,0);
            // 注：上面一行返回后，此行实际不会执行，仅为代码残留
            return OutColor;
        }	
    ]]

    // 4. 状态：Over（悬停状态，Logo变亮效果）
    MainCode PixelShaderOver
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取Logo主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                
        // 开启动画时，混合动画纹理（如悬停时Logo边缘发光）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;
        #endif

            // 用Color参数调整Logo色调（悬停时整体变亮）
            OutColor *= Color;
            
            // 悬停时的亮度增强（随时间变亮，突出交互反馈）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 4 );  // 变化较慢（系数4）
            vTime *= vTime;  // 平方运算让变化平滑
            vTime = 0.9*0.9 - vTime;  // 反向计算增强值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（提升亮度）
            OutColor.rgb += ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 增加RGB亮度

            return OutColor;
        }
    ]]
}


// ==============================================================
// 混合状态（BlendState）：控制Logo与下层元素的叠加方式
// 启用混合确保Logo的半透明区域（如边缘、文字抗锯齿）正确叠加
// ==============================================================
BlendState BlendState
{
    BlendEnable = yes  // 启用混合（支持Logo半透明效果）
    SourceBlend = "src_alpha"  // 自身颜色占比=自身透明度
    DestBlend = "inv_src_alpha"  // 下层颜色占比=1-自身透明度
    // 最终颜色 = Logo颜色*透明度 + 下层颜色*(1-透明度)（确保Logo与背景自然融合）
}


// ==============================================================
// 效果定义（Effect）：组合顶点和像素着色器，供游戏调用
// 游戏根据Logo的状态（正常/按下/禁用/悬停）自动切换
// ==============================================================
Effect Up  // 正常状态：106.5~116.5秒，渐入→稳定显示→渐出（伴随缓慢缩放）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderUp"
}

Effect Down  // 按下状态：Logo变暗
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDown"
}

Effect Disable  // 禁用状态：灰度处理后隐藏（不显示）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDisable"
}

Effect Over  // 悬停状态：Logo变亮
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderOver"
}