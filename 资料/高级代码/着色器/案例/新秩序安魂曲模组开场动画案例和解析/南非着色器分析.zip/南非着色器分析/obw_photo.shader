// ==============================================================
// 文件名：obw_photo.shader
// 作用：控制钢铁雄心4中"照片类元素"的显示效果与动态动画
// 适用场景：游戏中的图片、照片类内容（如历史图片、事件插图、人物肖像等视觉素材）
// 核心功能：通过纹理坐标变换实现照片的全生命周期动态，包括：
//          - 正常状态：79.5~88.5秒内，1秒快速Y方向移入→8秒稳定显示；
//          - 禁用状态：88.5秒后，2秒高频抖动→1.5秒顺时针旋转移出→最终隐藏；
//          - 交互反馈：按下时照片变暗、悬停时照片变亮（保持统一的操作反馈逻辑）。
// 与其他元素的核心差异：
//          1. 时间定位：作为中期出现的内容，时间窗口（约9秒）介于核心标志（8秒）与Logo（更长）之间；
//          2. 动画逻辑：聚焦"自然过渡"，以移入-稳定-移出的完整流程模拟真实照片展示体验；
//          3. 消失方式：采用抖动+旋转的组合动画，而非燃烧或单纯缩放，贴合照片"被移除"的视觉隐喻。
// ==============================================================


// ==============================================================
// 引入外部工具包（复用通用功能）
// 额外引入燃烧效果工具（虽未直接使用，可能为扩展预留）
// ==============================================================
Includes = {
    "buttonstate.fxh"        // 按钮状态逻辑（按下/悬停判断）
    "sprite_animation.fxh"   // 精灵动画函数（支持照片的动态效果）
    "/intros/saf/burn.fxh"   // 燃烧效果工具（预留，可能用于特殊消失动画）
}


// ==============================================================
// 像素着色器采样器（Samplers）：定义纹理读取规则
// 针对照片优化，确保图片细节清晰、边缘平滑（尤其动态移动时）
// ==============================================================
PixelShader =
{
    Samplers =
    {
        MapTexture =  // 主纹理（照片的基础图像，如历史图片、插图内容）
        {
            Index = 0  // 对应游戏传入的第0张图片（照片原图）
            MagFilter = "Linear"  // 放大时平滑过渡（避免照片细节模糊）
            MinFilter = "Linear"  // 缩小时平滑过渡
            MipFilter = "None"    // 不启用多级渐远纹理（照片无需远处模糊）
            AddressU = "Clamp"    // 超出范围时拉伸边缘（避免照片重复错位）
            AddressV = "Clamp"
            MipMapLodBias = -0.8  // 微调清晰度（增强照片细节，如纹理、文字）
        }
        MaskTexture =  // 动画遮罩1（控制照片局部动态，如部分区域高亮）
        {
            Index = 1  // 对应第1张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture =  // 动画纹理1（照片的动态效果，如边缘淡入）
        {
            Index = 2  // 对应第2张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"  // 超出范围时重复（适合循环动画，如闪烁）
            AddressV = "Wrap"
        }
        MaskTexture2 =  // 动画遮罩2（备用遮罩，用于复杂动态分层）
        {
            Index = 3  // 对应第3张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture2 =  // 动画纹理2（第二套动态效果，如颜色渐变）
        {
            Index = 4  // 对应第4张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"
            AddressV = "Wrap"
        }
        // 主遮罩（控制照片的整体可见形状，如仅显示照片内框区域）
        MaskingTexture =
        {
            Index = 5  // 对应第5张图片
            MagFilter = "Point"  // 点过滤（保留照片边缘锐度，避免边框模糊）
            MinFilter = "Point"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
    }
}


// ==============================================================
// 顶点输出结构（VS_OUTPUT）：顶点着色器传递给像素着色器的数据
// 包含位置、纹理坐标，支持条件编译的动画/遮罩坐标（适配照片动态）
// ==============================================================
VertexStruct VS_OUTPUT
{
    float4  vPosition : PDX_POSITION;  // 像素在屏幕上的最终位置
    float2  vTexCoord : TEXCOORD0;     // 主纹理坐标（读取照片的位置）
@ifdef ANIMATED  // 开启动画时，包含动画纹理坐标（如动态效果位置）
    float4  vAnimatedTexCoord : TEXCOORD1;
@endif
@ifdef MASKING  // 开启遮罩时，包含主遮罩坐标（控制照片显示范围）
    float2  vMaskingTexCoord : TEXCOORD2;
@endif
};


// ==============================================================
// 顶点着色器（VertexShader）：计算照片的位置和基础纹理坐标
// 结构简单，仅负责位置转换和纹理坐标传递（动态效果由像素着色器处理）
// ==============================================================
VertexShader =
{
    MainCode VertexShader
    [[
        VS_OUTPUT main(const VS_INPUT v )
        {
            VS_OUTPUT Out;
            // 计算屏幕位置：通过投影矩阵将3D坐标转为屏幕2D坐标
            Out.vPosition  = mul( WorldViewProjectionMatrix, float4( v.vPosition.xyz, 1 ) );
        
            // 传递主纹理坐标（告诉像素着色器该读取照片的哪个部分）
            Out.vTexCoord = v.vTexCoord;
        
            return Out;
        }
    ]]
}


// ==============================================================
// 像素着色器（PixelShader）：核心逻辑，控制照片的动态展示
// 重点：Up状态实现照片"快速移入"，Disable状态实现"抖动+旋转移出"，时间窗口明确
// ==============================================================
PixelShader =
{
    // 1. 状态：Up（正常显示状态，照片的出现与稳定展示）
    MainCode PixelShaderUp
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取照片主纹理颜色（初始颜色）
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            
            // 【控制参数1：Offset.x】强制隐藏开关
            // 若Offset.x的整数部分+1等于2，则照片完全透明（不显示）
            float value = floor(Offset.x) + 1.f;  // floor取整数部分（如1.8→1）
            if(value == 2)
            {
                return float4(0,0,0,0);  // 全透明（隐藏）
            }
            
            // 计算动画时间：当前时间(Time) - 动画开始时间(AnimationTime)
            float vTime = Time - AnimationTime;
            
            // 时间窗口外（<79.5秒）：照片完全透明（不显示）
            if(vTime < 79.5)
            {
                return float4(0,0,0,0);
            }
            // 阶段1：79.5~80.5秒（1秒窗口）→ 照片快速移入（Y方向位移动画）
            else if(vTime >= 79.5 && vTime < 80.5)
            {
                float2 newTexCoord = v.vTexCoord;  // 变换后的纹理坐标
                // Y方向位移：1 - sin(...) → sin从0→sin(1.5)≈0.997，故位移从1→0.003（快速向上移动）
                // 效果：照片从下方快速移入视野，1秒内稳定到正常位置
                newTexCoord.y += 1.f - sin((vTime - 79.5)*1.5f);
                
                // 限制显示范围：位移后超出[0,1]范围的区域隐藏（避免照片显示不完整）
                if(newTexCoord.y > 1 || newTexCoord.y < 0)
                {
                    return float4(0,0,0,0);
                }
                // 用变换后的坐标读取纹理（实现移入动画）
                OutColor = tex2D( MapTexture, newTexCoord );
            }
            // 时间窗口外（>88.5秒）：照片完全透明（不显示）
            else if(vTime > 88.5)
            {
                return float4(0,0,0,0);
            }
            // 阶段2：80.5~88.5秒（8秒窗口）→ 照片稳定显示（无动态）
            
            return OutColor;
        }
    ]]

    // 2. 状态：Down（按下状态，照片变暗效果）
    MainCode PixelShaderDown
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取照片主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                    
        // 开启动画时，混合动画纹理（如按下时照片局部变暗）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度（如仅显示照片内框）
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;  // 遮罩透明区域让对应部分消失
        #endif
            
            // 用游戏传入的Color参数调整照片色调（按下时整体变暗）
            OutColor *= Color;

            // 按下时的亮度衰减（随时间变暗，增强交互反馈）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 16 );  // 限制值0~1
            vTime *= vTime;  // 平方运算让变化更平滑（先快后慢）
            vTime = 0.9*0.9 - vTime;  // 反向计算衰减值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（降低亮度）
            OutColor.rgb -= ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 降低RGB亮度

            return OutColor;
        }
    ]]

    // 3. 状态：Disable（禁用状态，照片的抖动+旋转消失动画）
    MainCode PixelShaderDisable
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取照片主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            
            // 【控制参数：Offset.x】强制隐藏（同Up状态）
            float value = floor(Offset.x) + 1.f;
            if(value == 2)
            {
                return float4(0,0,0,0);
            }
            
            // 计算动画时间：当前时间 - 动画开始时间
            float vTime = Time - AnimationTime;
            
            // 时间窗口外（<88.5秒）：照片完全透明（不显示）
            if(vTime < 88.5)
            {
                return float4(0,0,0,0);
            }
            // 阶段1：94.5~96.5秒（2秒窗口）→ 照片抖动效果
            else if(vTime >= 94.5 && vTime < 96.5)
            {
                // 抖动幅度：sin(vTime*100) → 高频波动（100次/秒），值在-1~1之间
                float shake = sin(vTime * 100.f);
                // 抖动纹理坐标：在原坐标基础上叠加±0.01的偏移（轻微抖动）
                float2 shakeUV = v.vTexCoord + 0.01f * shake;
                
                // 限制显示范围：抖动后超出[0,1]范围的区域隐藏
                if(shakeUV.x < 0 || shakeUV.x > 1 || shakeUV.y < 0 || shakeUV.y > 1)
                {
                    return float4(0,0,0,0);
                }
                // 用抖动后的坐标读取纹理（实现抖动效果，模拟照片不稳定）
                OutColor = tex2D( MapTexture, (v.vTexCoord + 0.01f * shake) );
            }
            // 阶段2：96.5~98秒（1.5秒窗口）→ 照片旋转移出
            else if(vTime >= 96.5 && vTime < 98)
            {
                // 旋转中心点：(0,1)（左上角，照片从左上角开始旋转）
                float2 pivot = float2(0.f, 1.f);
                // 旋转速度：-2.5弧度/秒（负号表示顺时针旋转）
                float speed  = -2.5f;

                // 旋转角度：随时间增加（96.5秒时0→98秒时约-3.75弧度，即顺时针旋转约215度）
                float angle = (vTime - 96.5) * speed;

                // 计算旋转后的纹理坐标（调用旋转函数RotateUV，绕pivot点旋转）
                float2 rotUV = RotateUV(v.vTexCoord, pivot, angle);
                
                // 限制显示范围：旋转后超出[0,1]范围的区域隐藏（模拟照片转出视野）
                if(rotUV.x < 0 || rotUV.x > 1 || rotUV.y < 0 || rotUV.y > 1)
                {
                    return float4(0,0,0,0);
                }

                // 用旋转后的坐标读取纹理（实现旋转移出效果）
                OutColor = tex2D(MapTexture, rotUV);
            }
            // 阶段3：≥98秒 → 照片完全透明（隐藏）
            else if(vTime >= 96.5)
            {
                return float4(0,0,0,0);
            }
            
            return OutColor;
        }	
    ]]

    // 4. 状态：Over（悬停状态，照片变亮效果）
    MainCode PixelShaderOver
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取照片主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                
        // 开启动画时，混合动画纹理（如悬停时照片边缘高亮）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;
        #endif

            // 用Color参数调整照片色调（悬停时整体变亮）
            OutColor *= Color;
            
            // 悬停时的亮度增强（随时间变亮，突出交互反馈）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 4 );  // 变化较慢（系数4）
            vTime *= vTime;  // 平方运算让变化平滑
            vTime = 0.9*0.9 - vTime;  // 反向计算增强值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（提升亮度）
            OutColor.rgb += ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 增加RGB亮度

            return OutColor;
        }
    ]]
}


// ==============================================================
// 混合状态（BlendState）：控制照片与下层元素的叠加方式
// 启用混合确保照片的半透明区域（如边缘、抗锯齿部分）正确叠加
// ==============================================================
BlendState BlendState
{
    BlendEnable = yes  // 启用混合（支持照片半透明效果）
    SourceBlend = "src_alpha"  // 自身颜色占比=自身透明度
    DestBlend = "inv_src_alpha"  // 下层颜色占比=1-自身透明度
    // 最终颜色 = 照片颜色*透明度 + 下层颜色*(1-透明度)（确保照片与背景自然融合）
}


// ==============================================================
// 效果定义（Effect）：组合顶点和像素着色器，供游戏调用
// 游戏根据照片的状态（正常/按下/禁用/悬停）自动切换
// ==============================================================
Effect Up  // 正常状态：79.5~88.5秒，1秒快速移入→8秒稳定显示
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderUp"
}

Effect Down  // 按下状态：照片变暗
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDown"
}

Effect Disable  // 禁用状态：88.5秒后，2秒抖动→1.5秒旋转移出→隐藏
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDisable"
}

Effect Over  // 悬停状态：照片变亮
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderOver"
}