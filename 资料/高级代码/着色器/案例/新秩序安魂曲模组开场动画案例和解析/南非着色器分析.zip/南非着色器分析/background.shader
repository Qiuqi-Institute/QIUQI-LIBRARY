// ==============================================================
// 文件名：background.shader
// 作用：控制钢铁雄心4中"最底层核心背景"的显示效果和动态动画
// 适用场景：游戏全局最底层的核心背景（如大地图基底、主界面底色、剧情场景背景）
// 核心功能：通过多阶段时间控制实现完整叙事型动画，包含：
//          - 开场黑屏过渡（0~12秒：渐显纯黑→保持纯黑→淡出显原图）
//          - 中期稳定展示（12~85秒：显示完整背景，支撑所有上层元素）
//          - 中期黑屏过渡（85~110.5秒：再次纯黑，衔接后期退场）
//          - 后期燃烧退场（110.5~120.5秒：从中心向外燃烧消失）
//          - 禁用状态特效（88~88.6秒：顶部扩散白色光环，强化剧情节点）
//          - 基础交互反馈（按下变暗、悬停变亮）
// 与上下层瓦片（background_tile_lower/upper）的核心差异：
//          1. 动画复杂度：多段黑屏过渡+中心燃烧，而非单一入场+角落燃烧；
//          2. 叙事作用：通过黑屏分割“开场-中期-后期”，引导流程节奏；
//          3. 特效独特性：禁用状态有专属白色光环，上下层无此特效；
//          4. 燃烧位置：从背景正中心燃烧，与上下层的四角燃烧形成视觉焦点。
// ==============================================================


// ==============================================================
// 引入外部工具包（复用通用功能，适配复杂动画需求）
// ==============================================================
Includes = {
    "buttonstate.fxh"      // 按钮状态逻辑（判断按下/悬停，支撑基础交互）
    "sprite_animation.fxh" // 精灵动画函数（提供纹理混合、序列帧等基础工具）
    "/intros/saf/burn.fxh" // 燃烧效果工具（核心依赖，实现中心扩散燃烧退场）
}


// ==============================================================
// 像素着色器采样器（Samplers）：定义纹理读取规则
// 结构与上下层瓦片完全一致，确保全场景纹理处理风格统一
// ==============================================================
PixelShader =
{
    Samplers =
    {
        MapTexture =  // 主纹理（核心背景图，如大地图、场景底色的原始图像）
        {
            Index = 0  // 对应游戏传入的第0张图片（核心背景原图）
            MagFilter = "Linear"  // 放大时平滑过渡（避免大尺寸背景出现锯齿）
            MinFilter = "Linear"  // 缩小时平滑过渡
            MipFilter = "None"    // 不启用多级渐远纹理（核心背景无需远处模糊）
            AddressU = "Clamp"    // 超出范围时拉伸边缘（避免背景重复错位）
            AddressV = "Clamp"
            MipMapLodBias = -0.8  // 微调清晰度（增强背景细节，如地图纹路、场景纹理）
        }
        MaskTexture =  // 动画遮罩1（控制局部动态区域，如背景流动效果的显示范围）
        {
            Index = 1  // 对应第1张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture =  // 动画纹理1（背景动态效果，如缓慢流动的云层、光影）
        {
            Index = 2  // 对应第2张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"  // 超出范围时重复（适合循环动画，如光影流动）
            AddressV = "Wrap"
        }
        MaskTexture2 =  // 动画遮罩2（备用遮罩，用于复杂分层动态控制）
        {
            Index = 3  // 对应第3张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture2 =  // 动画纹理2（第二套动态效果，如颜色渐变、局部闪烁）
        {
            Index = 4  // 对应第4张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"
            AddressV = "Wrap"
        }
        // 主遮罩（控制核心背景的整体可见形状，如仅显示屏幕内区域、不规则边缘裁剪）
        MaskingTexture =
        {
            Index = 5  // 对应第5张图片
            MagFilter = "Point"  // 点过滤（保留遮罩边缘锐度，确保背景边界清晰）
            MinFilter = "Point"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
    }
}


// ==============================================================
// 顶点输出结构（VS_OUTPUT）：顶点着色器传递给像素着色器的数据
// 通用结构，包含位置、纹理坐标，支持动画/遮罩的条件编译扩展
// ==============================================================
VertexStruct VS_OUTPUT
{
    float4  vPosition : PDX_POSITION;  // 像素在屏幕上的最终位置（坐标）
    float2  vTexCoord : TEXCOORD0;     // 主纹理坐标（告诉像素该读取背景图的哪个点）
@ifdef ANIMATED  // 开启动画时，包含动画纹理坐标（动态效果的位置信息）
    float4  vAnimatedTexCoord : TEXCOORD1;
@endif
@ifdef MASKING  // 开启遮罩时，包含主遮罩坐标（控制背景显示范围）
    float2  vMaskingTexCoord : TEXCOORD2;
@endif
};


// ==============================================================
// 顶点着色器（VertexShader）：计算背景的位置和基础纹理坐标
// 所有状态共用，功能与上下层瓦片一致（仅负责位置转换和坐标传递）
// ==============================================================
VertexShader =
{
    MainCode VertexShader
    [[
        VS_OUTPUT main(const VS_INPUT v )
        {
            VS_OUTPUT Out;
            // 计算屏幕位置：通过投影矩阵将3D世界坐标转为屏幕2D显示坐标
            Out.vPosition  = mul( WorldViewProjectionMatrix, float4( v.vPosition.xyz, 1 ) );
        
            // 传递主纹理坐标（将原始纹理坐标传递给像素着色器）
            Out.vTexCoord = v.vTexCoord;
        
            return Out;
        }
    ]]
}


// ==============================================================
// 像素着色器（PixelShader）：核心动画逻辑，分状态处理
// 重点：Up状态的多阶段黑屏+燃烧退场，Disable状态的专属光环特效
// ==============================================================
PixelShader =
{
    // 1. 状态：Up（正常显示状态，核心背景的主动画流程）
    MainCode PixelShaderUp
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取核心背景的原始颜色（基础底色）
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            
            // 【控制参数1：Offset.x】强制隐藏开关
            // 若Offset.x的整数部分+1等于2，则背景完全透明（不显示）
            float value = floor(Offset.x) + 1.f;  // floor取整数部分（如1.7→1）
            if(value == 2)
            {
                return float4(0,0,0,0);  // 全透明（隐藏）
            }
            
            // 计算动画时间：当前时间(Time) - 动画开始时间(AnimationTime)
            // 控制整个背景的多阶段流程
            float vTime = Time - AnimationTime;
            
            // 阶段1：0~2秒 → 开场黑屏渐显（从透明→纯黑）
            if(vTime < 2.f)
            {
                OutColor = float4(0,0,0,1);  // 颜色设为黑色
                OutColor.a = vTime * 0.5f;   // 透明度随时间线性增加（2秒时完全不透明）
                // 效果：模拟“屏幕逐渐变黑”，为后续场景铺垫氛围
            }
            // 阶段2：2~10秒 → 保持纯黑（无变化，预留剧情/加载时间）
            else if(vTime >= 2.f && vTime < 10.f)
            {
                OutColor = float4(0,0,0,1);  // 纯黑屏幕，遮挡背景原图
            }
            // 阶段3：10~12秒 → 黑屏淡出，显示原始背景（从纯黑→原图）
            else if(vTime >= 10.f && vTime < 12.f)
            {
                // 原图透明度随时间增加（10秒时0→12秒时1，完全显示原图）
                OutColor.a *= (vTime - 10.f) * 0.5f;
                
                float4 black = float4(0,0,0,1);  // 要淡出的黑色
                float4 finalColour = float4(0,0,0,0);  // 最终混合后的颜色
                
                // 手动计算颜色混合（模拟透明度叠加，避免淡出过渡生硬）
                // 最终透明度 = 1 - (1-原图透明度) * (1-黑色透明度)
                finalColour.a = 1.f - ((1.f - black.a) * (1.f - OutColor.a));
                // 最终RGB = （原图颜色*原图透明度 + 黑色*黑色透明度*(1-原图透明度)） / 最终透明度
                finalColour.r = (OutColor.r * OutColor.a + black.r * black.a * (1 - OutColor.a)) / finalColour.a;
                finalColour.g = (OutColor.g * OutColor.a + black.g * black.a * (1 - OutColor.a)) / finalColour.a;
                finalColour.b = (OutColor.b * OutColor.a + black.b * black.a * (1 - OutColor.a)) / finalColour.a;
                
                return finalColour;  // 返回混合色，实现“黑色逐渐退去，原图逐渐显现”
            }
            // 阶段4：85~110.5秒 → 中期黑屏过渡（再次纯黑，衔接后期退场）
            else if(vTime > 85.f && vTime < 110.5f)
            {
                return float4(0,0,0,1);  // 纯黑屏幕，分割中期与后期流程
            }
            // 阶段5：110.5~120.5秒 → 后期燃烧退场（从中心向外扩散燃烧）
            else if(vTime > 110.5f && vTime < 120.5f)
            {
                // 燃烧效果参数配置（调用burn.fxh中的ApplyBurnColour函数）
                float4 colour = float4(0,0,0,1);  // 燃烧区域的基础色（黑色）
                float2 BurnCenter = float2(0.5f, 0.5f);  // 燃烧中心（背景正中心，视觉焦点）
                float Aspect = 1.8f;  // 宽高比（适配宽屏，避免燃烧圆形被拉伸为椭圆）
                float cTime = vTime - 110.5f;  // 燃烧动画本地时间（从0开始计时）
                float Radius0 = 0.0f;  // 初始燃烧半径（从中心点开始）
                float Speed = 0.25f;  // 燃烧扩展速度（比上下层瓦片快，0.25>0.13/0.133，快速覆盖全屏）
                float JagAmp = 0.01f;  // 燃烧边缘锯齿幅度（轻微不规则，模拟真实火焰）
                float Freq = 4.f;      // 锯齿频率（中等密度，边缘细节适中）
                float Flow = 0.8f;     // 锯齿流动速度（模拟火焰向上飘动的动态）
                float EdgeWidth = 0.01f; // 燃烧边缘过渡宽度（较窄，边缘清晰）
                float RimWidth = 0.001f; // 火焰光晕宽度（几乎无，避免抢镜）
                float RimSigma = 0.005f; // 光晕模糊度（轻微模糊，增强真实感）
                float HeatAmp = 0.003f;  // 热扭曲幅度（轻微扭曲背景，模拟热浪）
                float3 EmberColor = float3(0.8, 0.6, 0.4); // 火焰颜色（浅橙褐色，贴近自然火焰）
                float EmberBoost = 0.05f; // 火焰亮度（较暗，不掩盖其他元素退场）
                
                // 调用燃烧效果函数，返回从中心扩散的燃烧颜色
                float4 burn = ApplyBurnColour(v.vTexCoord, colour, BurnCenter, Aspect, cTime, 
                                             Radius0, Speed, JagAmp, Freq, Flow, 
                                             EdgeWidth, RimWidth, RimSigma, HeatAmp, 
                                             EmberColor, EmberBoost);
                return burn;  // 显示燃烧效果，背景逐渐被黑色覆盖
            }
            // 阶段6：>120.5秒 → 完全透明（燃烧退场完成，隐藏）
            else if(vTime > 120.5f)
            {
                return float4(0,0,0,0);
            }
            
            // 其他时间（12~85秒）：显示原始核心背景（稳定支撑上层所有元素）
            return OutColor;
        }
    ]]

    // 2. 状态：Down（按下状态，背景变暗交互反馈）
    MainCode PixelShaderDown
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取核心背景原始颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                    
        // 开启动画时，混合动画纹理（如按下时的波纹、局部暗化效果）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度（限制背景显示范围）
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;  // 遮罩透明区域让背景对应部分消失
        #endif
            
            // 用游戏传入的Color参数调整整体色调（按下时叠加暗化滤镜）
            OutColor *= Color;

            // 按下时的亮度衰减计算（随时间变暗，强化交互反馈）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 16 );  // 限制值0~1
            vTime *= vTime;  // 平方运算让变化更平滑（先快后慢）
            vTime = 0.9*0.9 - vTime;  // 反向计算衰减值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（降低亮度）
            OutColor.rgb -= ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 降低RGB亮度

            return OutColor;
        }
    ]]

    // 3. 状态：Disable（禁用状态，专属白色光环特效）
    MainCode PixelShaderDisable
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取核心背景原始颜色（此状态下几乎不用，仅为结构完整）
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            // 计算动画时间：当前时间 - 动画开始时间
            float vTime = Time - AnimationTime;
            
            // 【控制参数：Offset.x】强制隐藏（同Up状态）
            float value = floor(Offset.x) + 1.f;
            if(value == 2)
            {
                return float4(0,0,0,0);
            }
            
            // 阶段1：88秒前 → 完全透明（不显示，等待触发时机）
            if(vTime < 88)
            {
                return float4(0,0,0,0);
            }
            // 阶段2：88~88.375秒（0.375秒窗口）→ 第一波白色光环（顶部中心扩散）
            else if(vTime >= 88 && vTime < 88.375)
            {
                float2 centre = float2(0.5, 0);  // 光环中心（背景顶部中点，y=0为最上）
                float4 colour = float4(0.9, 0.9, 0.9, 1);  // 光环颜色（近白色，亮度高）
                
                // 计算光环半径（通过双重cos函数，实现“快速扩张→缓慢收尾”的脉冲效果）
                float radius = 1.f - cos((1.f - (cos((vTime - 88) * 4.f))) * 4.f);
                
                // 计算当前像素到光环中心的距离（欧氏距离，模拟屏幕空间距离）
                float distToCentre = sqrt(
                    (v.vTexCoord.x - 0.5f) * (v.vTexCoord.x - 0.5f) +  // X方向距离平方
                    v.vTexCoord.y * v.vTexCoord.y                      // Y方向距离平方（中心y=0）
                );
                
                // 像素在光环内（距离<半径）：显示不透明白色
                if(distToCentre < radius)
                {
                    return colour;
                }
                // 像素在光环边缘（半径<距离<半径+0.05）：透明度渐变（避免边缘生硬）
                else if(distToCentre > radius && distToCentre < radius + 0.05)
                {
                    float alpha = 1.f - ((distToCentre - radius) / 0.05f);  // 透明度从1→0
                    colour.a = alpha;
                    return colour;
                }
            }
            // 阶段3：88.375~88.6秒（0.225秒窗口）→ 第二波白色光环（更快更宽）
            else if(vTime >= 88.375 && vTime < 88.6)
            {
                float2 centre = float2(0.5, 0);  // 同一中心（顶部中点）
                float4 colour = float4(0.9, 0.9, 0.9, 1);  // 同样近白色
                
                // 半径计算：系数6>4，扩张速度更快，覆盖范围更广
                float radius = 1.f - (1.f - cos((1.f - (cos((vTime - 88.375) * 6.f))) * 6.f));
                
                // 计算到中心的距离（同前）
                float distToCentre = sqrt(
                    (v.vTexCoord.x - 0.5f) * (v.vTexCoord.x - 0.5f) + 
                    v.vTexCoord.y * v.vTexCoord.y
                );
                
                // 光环内显示白色，边缘渐变透明
                if(distToCentre < radius)
                {
                    return colour;
                }
                else if(distToCentre > radius && distToCentre < radius + 0.05)
                {
                    float alpha = 1.f - ((distToCentre - radius) / 0.05f);
                    colour.a = alpha;
                    return colour;
                }
            }
            
            // 所有阶段外：完全透明（不显示）
            return float4(0,0,0,0);
        }	
    ]]

    // 4. 状态：Over（悬停状态，背景变亮交互反馈）
    MainCode PixelShaderOver
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取核心背景原始颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                
        // 开启动画时，混合动画纹理（如悬停时的微光、局部高亮）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;
        #endif

            // 用游戏传入的Color参数调整整体色调（悬停时叠加亮化滤镜）
            OutColor *= Color;
            
            // 悬停时的亮度增强计算（随时间变亮，突出交互反馈）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 4 );  // 变化较慢（系数4）
            vTime *= vTime;  // 平方运算让变化更平滑
            vTime = 0.9*0.9 - vTime;  // 反向计算增强值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（提升亮度）
            OutColor.rgb += ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 增加RGB亮度

            return OutColor;
        }
    ]]
}


// ==============================================================
// 混合状态（BlendState）：控制背景与其他元素的叠加方式
// 与上下层瓦片一致，确保透明区域（如燃烧边缘、光环边缘）自然融合
// ==============================================================
BlendState BlendState
{
    BlendEnable = yes  // 启用混合（支持透明度效果）
    SourceBlend = "src_alpha"  // 自身颜色占比=自身透明度
    DestBlend = "inv_src_alpha"  // 下层颜色占比=1-自身透明度
    // 最终颜色 = 背景颜色*透明度 + 其他元素颜色*(1-透明度)
    // 例：燃烧边缘的半透明像素，会自然混合背景和上层元素颜色
}


// ==============================================================
// 效果定义（Effect）：组合顶点和像素着色器，供游戏调用
// 游戏根据核心背景的状态（正常/按下/禁用/悬停）自动切换
// ==============================================================
Effect Up  // 正常状态：多阶段黑屏过渡+中心燃烧退场（核心动画）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderUp"
}

Effect Down  // 按下状态：背景变暗（交互反馈）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDown"
}

Effect Disable  // 禁用状态：88~88.6秒顶部白色光环（专属特效）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDisable"
}

Effect Over  // 悬停状态：背景变亮（交互反馈）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderOver"
}