// ==============================================================
// 文件名：borders_glow.shader
// 作用：控制钢铁雄心4中"发光边框元素"的显示效果与动态动画
// 适用场景：游戏中带发光效果的边框（如高亮区域边框、交互元素边缘发光、重要区域发光轮廓等）
// 核心功能：通过纹理坐标变换实现发光动态效果，包括：
//          - 正常状态：34~70秒内周期性缩放（以固定中心放大缩小）并逐渐淡出；
//          - 禁用状态：34~70秒同正常缩放→70~85秒固定缩小→85秒后完全隐藏；
//          - 交互反馈：按下时发光变暗、悬停时发光变亮（保持发光风格统一）。
// 与普通边框（borders_full）的核心差异：
//          1. 动画方式：无燃烧效果，通过纹理缩放实现发光动态，而非燃烧退场；
//          2. 时间窗口：显示时间更靠后（34秒后），与普通边框的12~34秒窗口错开；
//          3. 视觉焦点：侧重发光效果的动态变化（缩放、明暗），而非区域界定的静态展示。
// ==============================================================


// ==============================================================
// 引入外部工具包（复用通用功能）
// 注意：相比普通边框，未引入燃烧效果工具（无需燃烧动画）
// ==============================================================
Includes = {
    "buttonstate.fxh"      // 按钮状态逻辑（按下/悬停判断）
    "sprite_animation.fxh" // 精灵动画函数（序列帧、纹理混合，支持发光动画）
}


// ==============================================================
// 像素着色器采样器（Samplers）：定义纹理读取规则
// 结构与普通边框一致，但针对发光效果优化了纹理过滤（保持发光边缘平滑）
// ==============================================================
PixelShader =
{
    Samplers =
    {
        MapTexture =  // 主纹理（发光边框的基础图像，含发光颜色和轮廓）
        {
            Index = 0  // 对应游戏传入的第0张图片
            MagFilter = "Linear"  // 放大时平滑过渡（避免发光边缘锯齿）
            MinFilter = "Linear"  // 缩小时平滑过渡（保持发光柔和）
            MipFilter = "None"    // 不启用多级渐远纹理（发光效果无需远处模糊）
            AddressU = "Clamp"    // 超出范围时拉伸边缘（避免发光边框重复错位）
            AddressV = "Clamp"
            MipMapLodBias = -0.8  // 微调清晰度（增强发光细节）
        }
        MaskTexture =  // 动画遮罩1（控制发光区域的动态显示，如部分发光闪烁）
        {
            Index = 1  // 对应第1张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture =  // 动画纹理1（发光效果的动态变化，如流动光效）
        {
            Index = 2  // 对应第2张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"  // 超出范围时重复（适合循环发光动画）
            AddressV = "Wrap"
        }
        MaskTexture2 =  // 动画遮罩2（备用遮罩，用于复杂发光分层）
        {
            Index = 3  // 对应第3张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture2 =  // 动画纹理2（第二套发光动态效果）
        {
            Index = 4  // 对应第4张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"
            AddressV = "Wrap"
        }
        // 主遮罩（控制发光边框的整体形状，如仅显示特定区域的发光边缘）
        MaskingTexture =
        {
            Index = 5  // 对应第5张图片
            MagFilter = "Point"  // 点过滤（保留发光边框的清晰边界）
            MinFilter = "Point"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
    }
}


// ==============================================================
// 顶点输出结构（VS_OUTPUT）：顶点着色器传递给像素着色器的数据
// 包含位置、纹理坐标，支持条件编译的动画/遮罩坐标（适配发光动画）
// ==============================================================
VertexStruct VS_OUTPUT
{
    float4  vPosition : PDX_POSITION;  // 像素在屏幕上的最终位置
    float2  vTexCoord : TEXCOORD0;     // 主纹理坐标（读取发光边框的位置）
@ifdef ANIMATED  // 开启动画时，包含发光动画的纹理坐标
    float4  vAnimatedTexCoord : TEXCOORD1;
@endif
@ifdef MASKING  // 开启遮罩时，包含主遮罩坐标（控制发光区域）
    float2  vMaskingTexCoord : TEXCOORD2;
@endif
};


// ==============================================================
// 顶点着色器（VertexShader）：计算发光边框的位置和纹理坐标
// 相比普通边框，增加了纹理坐标偏移和动画坐标处理（适配发光动态）
// ==============================================================
VertexShader =
{
    MainCode VertexShader
    [[
        VS_OUTPUT main(const VS_INPUT v )
        {
            VS_OUTPUT Out;
            // 计算屏幕位置：通过投影矩阵将3D坐标转为屏幕2D坐标
            Out.vPosition  = mul( WorldViewProjectionMatrix, float4( v.vPosition.xyz, 1 ) );
        
            // 处理主纹理坐标：基础坐标 + 偏移量（Offset由游戏传入，控制边框位置微调）
            Out.vTexCoord = v.vTexCoord;
            Out.vTexCoord += Offset;  // 偏移量用于动态调整边框位置（如随界面移动）
            
        // 开启动画时，获取动画纹理坐标（用于发光动态效果，如光效流动）
        #ifdef ANIMATED
            Out.vAnimatedTexCoord = GetAnimatedTexcoord(v.vTexCoord);  // 调用动画坐标函数
        #endif

        // 开启遮罩时，处理主遮罩坐标（将纹理坐标范围限制在[0,1]，确保遮罩正确）
        #ifdef MASKING
            // 技巧：将坐标放大1000倍后取饱和值（>0的坐标都转为1，0保持0）
            // 目的：让遮罩纹理只按区域显示（非黑即白，避免边缘模糊）
            Out.vMaskingTexCoord = saturate(v.vTexCoord * 1000); 
        #endif
        
            return Out;
        }
    ]]
}


// ==============================================================
// 像素着色器（PixelShader）：核心逻辑，控制发光边框的动态效果
// 重点：Up/Disable状态通过纹理坐标变换实现缩放动画，无燃烧效果
// ==============================================================
PixelShader =
{
    // 1. 状态：Up（正常显示状态，发光边框的周期性缩放+淡出）
    MainCode PixelShaderUp
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取发光边框主纹理颜色（原始发光色）
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            
            // 【控制参数1：Offset.x】强制隐藏开关
            // 若Offset.x的整数部分+1等于2，则发光边框完全透明（不显示）
            float value = floor(Offset.x) + 1.f;  // floor取整数部分（如1.3→1）
            if(value == 2)
            {
                return float4(0,0,0,0);  // 全透明（隐藏）
            }
            
            // 计算动画时间：当前时间(Time) - 动画开始时间(AnimationTime)
            float vTime = Time - AnimationTime;
            
            // 阶段1：34秒前 → 发光边框完全透明（不显示）
            if(vTime < 34)
            {
                return float4(0,0,0,0);
            }
            // 阶段2：34~70秒 → 发光边框周期性缩放+逐渐淡出
            else if(vTime >= 34 && vTime <= 70)
            {
                // 缩放中心：(0.5747, 1.0731)（约为边框底部偏右位置，固定缩放中心）
                float2 centre = float2(0.5747f, 1.0731f);
                float2 newTexCoords = v.vTexCoord;  // 临时存储变换后的纹理坐标
                
                // 纹理坐标变换（实现以centre为中心的缩放）：
                newTexCoords -= centre;  // 坐标原点移到缩放中心（相对中心的偏移）
                // 缩放因子：1 + 2*sin(...) → 范围在(1-2)=-1到(1+2)=3之间（动态变化）
                // 周期计算：(vTime-34)/36 → 将36秒（70-34）映射到0~1，再乘1.5f控制频率
                newTexCoords /= (1 + 2*sin(((vTime-34)/36.f) * 1.5f));  // 除以缩放因子（>1缩小，<1放大）
                newTexCoords += centre;  // 坐标原点移回原位置
                
                // 用变换后的坐标读取纹理（实现缩放动画）
                OutColor = tex2D( MapTexture, newTexCoords );
                // 透明度随时间降低：36秒时1→70秒时0（(70-36)=34秒，线性衰减）
                OutColor.a *= 1.f - ((vTime-36)/34.f);
            }
            // 阶段3：70秒后 → 完全透明（隐藏）
            else
            {
                return float4(0,0,0,0);
            }
            
            return OutColor;
        }
    ]]

    // 2. 状态：Down（按下状态，发光边框变暗效果）
    MainCode PixelShaderDown
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取发光边框主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                    
        // 开启动画时，混合动画纹理（如按下时发光闪烁）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制发光透明度（如仅部分区域发光）
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;  // 遮罩透明区域让对应发光部分消失
        #endif
            
            // 用游戏传入的Color参数调整发光色调（如按下时发光变暗）
            OutColor *= Color;

            // 按下时的亮度衰减（随时间变暗，保持发光风格）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 16 );  // 限制值0~1
            vTime *= vTime;  // 平方运算让变化更平滑（先快后慢）
            vTime = 0.9*0.9 - vTime;  // 反向计算衰减值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（降低发光亮度）
            OutColor.rgb -= ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 降低RGB亮度

            return OutColor;
        }
    ]]

    // 3. 状态：Disable（禁用状态，发光边框的持续缩放+消失）
    MainCode PixelShaderDisable
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取发光边框主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            
            // 【控制参数：Offset.x】强制隐藏（同Up状态）
            float value = floor(Offset.x) + 1.f;
            if(value == 2)
            {
                return float4(0,0,0,0);
            }
            
            // 计算动画时间（当前时间 - 动画开始时间）
            float vTime = Time - AnimationTime;
            
            // 阶段1：34秒前 → 完全透明（不显示）
            if(vTime < 34)
            {
                return float4(0,0,0,0);
            }
            // 阶段2：34~70秒 → 周期性缩放（与Up状态相同的动态缩放）
            else if(vTime >= 34 && vTime <= 70)
            {
                float2 centre = float2(0.5747f, 1.0731f);  // 同一缩放中心（底部偏右）
                float2 newTexCoords = v.vTexCoord;
                
                // 相同的坐标变换逻辑（以中心缩放，sin函数控制周期）
                newTexCoords -= centre;
                newTexCoords /= (1 + 2*sin(((vTime-34)/36.f) * 1.5f));
                newTexCoords += centre;
                
                OutColor = tex2D( MapTexture, newTexCoords );  // 缩放后颜色（无透明度衰减）
            }
            // 阶段3：70~85秒 → 固定缩小（缩放因子=3，持续缩小）
            else if(vTime > 70 && vTime < 85)
            {
                float2 centre = float2(0.5747f, 1.0731f);  // 同一中心
                float2 newTexCoords = v.vTexCoord;
                
                newTexCoords -= centre;
                newTexCoords /= 3;  // 固定除以3（缩小到1/3大小）
                newTexCoords += centre;
                
                OutColor = tex2D( MapTexture, newTexCoords );  // 缩小后的颜色
            }
            // 阶段4：85秒后 → 完全透明（隐藏）
            else if(vTime > 85)
            {
                return float4(0,0,0,0);
            }
            
            return OutColor;
        }	
    ]]

    // 4. 状态：Over（悬停状态，发光边框变亮效果）
    MainCode PixelShaderOver
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取发光边框主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                
        // 开启动画时，混合动画纹理（如悬停时发光增强）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;
        #endif

            // 用Color参数调整发光色调（如悬停时发光变亮）
            OutColor *= Color;
            
            // 悬停时的亮度增强（随时间变亮，强化发光效果）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 4 );  // 变化较慢（系数4）
            vTime *= vTime;  // 平方运算让变化平滑
            vTime = 0.9*0.9 - vTime;  // 反向计算增强值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（提升发光亮度）
            OutColor.rgb += ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 增加RGB亮度

            return OutColor;
        }
    ]]
}


// ==============================================================
// 混合状态（BlendState）：控制发光边框与下层元素的叠加方式
// 启用混合确保发光效果的半透明区域正确叠加（如发光边缘柔和过渡）
// ==============================================================
BlendState BlendState
{
    BlendEnable = yes  // 启用混合（支持发光半透明）
    SourceBlend = "src_alpha"  // 自身发光颜色占比=自身透明度
    DestBlend = "inv_src_alpha"  // 下层颜色占比=1-自身透明度
    // 最终颜色 = 发光颜色*透明度 + 下层颜色*(1-透明度)（确保发光不遮挡下层）
}


// ==============================================================
// 效果定义（Effect）：组合顶点和像素着色器，供游戏调用
// 游戏根据发光边框的状态（正常/按下/禁用/悬停）自动切换
// ==============================================================
Effect Up  // 正常状态：34~70秒周期性缩放+淡出
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderUp"
}

Effect Down  // 按下状态：发光变暗
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDown"
}

Effect Disable  // 禁用状态：34~70秒缩放→70~85秒缩小→隐藏
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDisable"
}

Effect Over  // 悬停状态：发光变亮
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderOver"
}