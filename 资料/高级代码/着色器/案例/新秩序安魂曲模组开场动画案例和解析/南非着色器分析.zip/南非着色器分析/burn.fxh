// ==============================================================
// 燃烧效果工具包（burn.fxh）
// 作用：提供从中心向外扩散的“燃烧”特效实现，包含以下功能：
// - 不规则的燃烧边缘（锯齿状，更自然）
// - 燃烧边缘的橙红色光晕（火焰发光效果）
// - 燃烧区域的变暗效果（烧焦的黑色）
// - 可选的热扭曲效果（火焰周围的空气扭曲）
// 可用于纹理图片（ApplyBurn）或纯色（ApplyBurnColour），被主着色器调用
// ==============================================================

PixelShader = 
{
    Code
    [[

        //==============================================================
        // 从中心燃烧效果（HLSL语言，适配SM5/DX11渲染模式）
        // - 随时间扩展圆形燃烧区域，边缘有锯齿和光晕
        // - 可用于全屏效果或任何带纹理坐标(UV)的素材
        //==============================================================

        //-------------------------
        // 辅助函数（工具函数，用于实现基础效果）
        //-------------------------

        // 平滑过渡函数（将值从0过渡到1，比普通lerp更自然）
        // 参数：e0=开始过渡的阈值，e1=结束过渡的阈值，x=当前值
        // 作用：x < e0时返回0，x > e1时返回1，中间平滑过渡
        float smoothstep01(float e0, float e1, float x)
        {
            float t = saturate((x - e0) / max(1e-6, (e1 - e0))); // 先将x归一化到0~1范围
            return t * t * (3.0 - 2.0 * t); // 用三次曲线让过渡更平滑（非线性）
        }

        // 2D哈希函数（生成伪随机数对，用于噪声生成）
        // 参数：p=输入坐标
        // 作用：将坐标转换为看起来随机的2D值（类似“指纹”，同一坐标输出固定但看起来随机）
        float2 hash22(float2 p)
        {
            // 用大质数相关的计算生成随机感（数学技巧，不用深究）
            float3 p3 = frac(float3(p.x, p.y, p.x) * float3(0.1031, 0.11369, 0.13787));
            p3 += dot(p3, p3.yzx + 19.19);
            return frac((p3.xx + p3.yz) * p3.zy);
        }

        // 2D噪声函数（生成类似“噪点”的平滑随机值）
        // 参数：p=输入坐标
        // 作用：输出-1~1的随机值，相邻坐标的值变化平滑（模拟自然噪声，如火焰的不规则）
        float noise2D(float2 p)
        {
            float2 i = floor(p); // 整数部分（网格坐标）
            float2 f = frac(p); // 小数部分（网格内的位置）

            // 用五次曲线让插值更平滑（减少块状感）
            float2 u = f * f * f * (f * (f * 6 - 15) + 10);

            // 计算四个角的随机值（用哈希函数）
            float2 a = hash22(i + float2(0,0));
            float2 b = hash22(i + float2(1,0));
            float2 c = hash22(i + float2(0,1));
            float2 d = hash22(i + float2(1,1));

            // 计算四个角到当前点的“距离”对应的随机值
            float va = dot(a, f - float2(0,0));
            float vb = dot(b, f - float2(1,0));
            float vc = dot(c, f - float2(0,1));
            float vd = dot(d, f - float2(1,1));

            // 平滑插值（先水平再垂直），得到最终噪声值
            float v1 = lerp(va, vb, u.x);
            float v2 = lerp(vc, vd, u.x);
            float v  = lerp(v1, v2, u.y);     
            return v; // 输出范围约-1~1
        }

        // 分形布朗运动（fBm，叠加多层噪声让效果更复杂）
        // 参数：p=输入坐标
        // 作用：将多层噪声叠加（类似海浪，一层大波浪加一层小波纹），让燃烧边缘更自然
        float fbm(float2 p)
        {
            float a = 0.0; // 累加噪声值
            float w = 0.5; // 每层噪声的权重（越来越小）
            float2 pp = p; // 坐标（每层放大一点）

            [unroll] for (int i = 0; i < 3; ++i) // 叠加3层噪声
            {
                a += w * noise2D(pp); // 累加当前层噪声（乘权重）
                pp = pp * 2.02; // 坐标放大（下一层细节更密）
                w *= 0.5; // 权重减半（大细节影响更大）
            }
            // 调整范围到-1~1（让效果更稳定）
            return saturate((a + 0.9) / 1.8) * 2.0 - 1.0;
        }

        //-------------------------
        // 核心燃烧效果函数（处理纹理图片）
        //-------------------------
        // 参数说明：
        // uv：当前像素在纹理上的坐标（类似图片上的(x,y)位置）
        // BaseTex：原始纹理（要燃烧的图片）
        // BurnCenter：燃烧中心坐标（如(0.5,0.5)是图片中心）
        // Aspect：宽高比（校正燃烧圆形在拉伸图片上的变形）
        // cTime：当前时间（控制燃烧进度）
        // Radius0：初始半径（燃烧开始时的大小）
        // Speed：燃烧扩展速度（越大烧得越快）
        // JagAmp：边缘锯齿幅度（越大边缘越不规则）
        // Freq：噪声频率（越大锯齿越密集）
        // Flow：噪声流动速度（模拟火焰飘动）
        // EdgeWidth：边缘过渡宽度（越大边缘越模糊）
        // RimWidth/RimSigma：光晕宽度/模糊度（控制边缘发光范围）
        // HeatAmp：热扭曲幅度（火焰周围的空气扭曲效果）
        // EmberColor：火焰颜色（如橙红色float3(1,0.5,0)）
        // EmberBoost：火焰亮度（越大越亮）
        float4 ApplyBurn(float2 uv,
                 in sampler2D BaseTex,
                 float2 BurnCenter, float Aspect, float cTime,
                 float Radius0, float Speed, float JagAmp, float Freq, float Flow,
                 float EdgeWidth, float RimWidth, float RimSigma, float HeatAmp,
                 float3 EmberColor, float EmberBoost)
        {
            // 1. 计算从像素到燃烧中心的距离（校正宽高比，避免圆形变椭圆）
            float2 p = uv - BurnCenter; // 像素到中心的偏移
            p.x *= Aspect; // 水平方向乘宽高比（如图片宽是高的2倍，x方向缩放2倍）
            float d = length(p); // 计算距离（得到圆形的半径）

            // 2. 计算燃烧扩展的半径（随时间变大）
            float r = Radius0 + Speed * cTime; // 初始半径 + 速度*时间（越久烧得越大）

            // 3. 生成燃烧边缘的不规则锯齿（用流动的噪声）
            float n  = fbm(p * Freq + Flow * cTime); // 噪声值（随时间流动，模拟火焰飘动）
            float dJ = d - JagAmp * n; // 距离减去噪声影响（让边缘凹凸不平）

            // 4. 计算边缘的平滑过渡宽度（抗锯齿，避免边缘太硬）
            // ddx/ddy是GPU函数，计算相邻像素的变化率，自动适配不同分辨率
            float fw = max(EdgeWidth, 2.0 * length(float2(ddx(dJ), ddy(dJ))));

            // 5. 生成燃烧区域的遮罩（1=已燃烧，0=未燃烧）
            // 用smoothstep01让边缘平滑过渡（抗锯齿）
            float burnMask = 1.0 - smoothstep01(r - fw, r + fw, dJ);

            // 6. 计算燃烧边缘的光晕（橙红色发光效果）
            // 用高斯函数生成环形光晕（中心亮，向外衰减）
            float rim = exp(-pow((dJ - r) / max(1e-5, RimSigma), 2.0));
            // 光晕闪烁效果（随时间和噪声变化，模拟火焰跳动）
            float flicker = 0.5 + 0.5 * sin(10.0 * cTime + 8.0 * n);

            // 7. 处理原始纹理颜色（转为黑白，只保留光晕颜色）
            float3 baseRGB = tex2D(BaseTex, uv).rgb; // 读取原始纹理颜色
            float  grey    = dot(baseRGB, float3(0.299, 0.587, 0.114)); // 转为灰度（黑白）
            float3 baseBW  = grey.xxx; // 灰度转RGB（黑白图）

            // 8. 燃烧区域的烧焦效果（更暗的黑色）
            float3 charred = lerp(float3(0.07, 0.06, 0.05), baseBW * 0.25, 0.6); // 深灰+暗黑白混合

            // 9. 合成颜色：未燃烧区域保留黑白，已燃烧区域显示烧焦效果
            float3 color = lerp(baseBW, charred, burnMask);

            // 10. 叠加边缘光晕（加色混合，让边缘发光）
            float3 ember = EmberColor * rim * flicker * EmberBoost; // 计算光晕颜色
            color += ember; // 叠加到主颜色上

            // 11. 可选：火焰周围的热扭曲效果（模拟空气被加热的扭曲）
            if (HeatAmp > 0.0)
            {
                float2 dir = (d > 1e-6) ? (p / d) : float2(0, 0); // 从中心到像素的方向
                // 扭曲偏移量（沿方向向外，受光晕和噪声影响）
                float2 distort  = dir * HeatAmp * rim * (0.5 + 0.5 * n);
                // 计算扭曲后的采样坐标（让像素看起来被拉扯）
                float2 sampleUV = uv + float2(distort.x / max(1e-6, Aspect), distort.y);
                // 用扭曲坐标采样纹理，模拟热空气扭曲
                float3 shimmer  = tex2D(BaseTex, sampleUV).rgb;
                float  shGrey   = dot(shimmer, float3(0.299, 0.587, 0.114));
                color = lerp(color, shGrey.xxx, 0.25 * rim); // 混合扭曲效果
            }

            // 12. 控制燃烧区域的可见性（已燃烧区域逐渐消失）
            float visibility = 1.0 - burnMask; // 可见度=1-燃烧遮罩（烧得越多越透明）

            // 返回最终颜色（RGB是燃烧效果，A是可见度）
            return float4(color, visibility);
        }
        
        //-------------------------
        // 核心燃烧效果函数（处理纯色，而非纹理）
        // 功能和ApplyBurn类似，区别：输入是纯色而非纹理图片
        //-------------------------
        float4 ApplyBurnColour(float2 uv,
                 float4 colour, // 输入的纯色（带透明度）
                 float2 BurnCenter, float Aspect, float cTime,
                 float Radius0, float Speed, float JagAmp, float Freq, float Flow,
                 float EdgeWidth, float RimWidth, float RimSigma, float HeatAmp,
                 float3 EmberColor, float EmberBoost)
        {
            // 1. 计算到燃烧中心的距离（同ApplyBurn）
            float2 p = uv - BurnCenter;
            p.x *= Aspect;
            float d = length(p);

            // 2. 燃烧扩展半径（同ApplyBurn）
            float r = Radius0 + Speed * cTime;

            // 3. 边缘锯齿（同ApplyBurn）
            float n  = fbm(p * Freq + Flow * cTime);
            float dJ = d - JagAmp * n;

            // 4. 边缘过渡宽度（同ApplyBurn）
            float fw = max(EdgeWidth, 2.0 * length(float2(ddx(dJ), ddy(dJ))));

            // 5. 燃烧遮罩（同ApplyBurn）
            float burnMask = 1.0 - smoothstep01(r - fw, r + fw, dJ);

            // 6. 边缘光晕（同ApplyBurn）
            float rim = exp(-pow((dJ - r) / max(1e-5, RimSigma), 2.0));
            float flicker = 0.5 + 0.5 * sin(10.0 * cTime + 8.0 * n);

            // 7. 处理输入的纯色（转为黑白，保留透明度）
            float4 baseSample = colour;
            float3 baseRGB = baseSample.rgb; // 纯色的RGB
            float  baseAlpha = baseSample.a; // 保留原始透明度

            // 转为灰度（黑白）
            float grey = dot(baseRGB, float3(0.299, 0.587, 0.114));
            float3 baseBW = grey.xxx;

            // 8. 烧焦效果（同ApplyBurn）
            float3 charred = lerp(float3(0.07, 0.06, 0.05), baseBW * 0.25, 0.6);

            // 9. 合成颜色（同ApplyBurn）
            float3 color = lerp(baseBW, charred, burnMask);

            // 10. 叠加光晕（同ApplyBurn）
            float3 ember = EmberColor * rim * flicker * EmberBoost;
            color += ember;

            // 11. 热扭曲效果（同ApplyBurn，但采样纯色）
            if (HeatAmp > 0.0)
            {
                float2 dir = (d > 1e-6) ? (p / d) : float2(0, 0);
                float2 distort = dir * HeatAmp * rim * (0.5 + 0.5 * n);
                float2 sampleUV = uv + float2(distort.x / max(1e-6, Aspect), distort.y);
                float4 shimmer = colour; // 用纯色计算扭曲（而非纹理）
                float shGrey = dot(shimmer.rgb, float3(0.299, 0.587, 0.114));
                color = lerp(color, shGrey.xxx, 0.25 * rim);
            }

            // 12. 最终透明度（原始透明度 * 可见度）
            float finalAlpha = baseAlpha * (1.0 - burnMask);

            return float4(color, finalAlpha);
        }

        //-------------------------
        // 纹理坐标旋转函数（辅助动画）
        // 作用：围绕指定中心点旋转UV坐标（让图片/效果旋转）
        //-------------------------
        // 参数：
        // uv：原始纹理坐标
        // pivot：旋转中心点（如(0.5,0.5)是中心）
        // angle：旋转角度（弧度，正数是顺时针）
        float2 RotateUV(float2 uv, float2 pivot, float angle)
        {
            // 1. 平移坐标：让旋转中心移到原点（方便计算）
            float2 p = uv - pivot;

            // 2. 旋转计算（用旋转矩阵，数学原理：绕原点旋转坐标）
            float s = sin(angle); // 正弦值
            float c = cos(angle); // 余弦值

            float2 rotated;
            rotated.x = c * p.x - s * p.y; // 旋转后的X坐标
            rotated.y = s * p.x + c * p.y; // 旋转后的Y坐标

            // 3. 平移回原来的位置
            return rotated + pivot;
        }

    ]]

}