// ==============================================================
// 文件名：anc_photo.shader
// 作用：控制钢铁雄心4中"历史照片元素"的显示效果和动态动画
// 适用场景：游戏剧情中的历史图片、档案照片（如战役记录、人物肖像、历史场景照片）
// 核心功能：在特定时间窗口（75~88.5秒）内呈现照片的完整叙事流程，包含：
//          - 平滑滑入动画（75~76秒，1秒快速进入视野）
//          - 稳定展示（76~88.5秒，约12.5秒供玩家观察细节）
//          - 抖动+旋转退出动画（88.5秒后，通过Disable状态实现退场）
//          - 按下/悬停时的亮度反馈（支持交互操作，如查看详情）
// 与其他元素的差异：作为中期核心内容载体，通过“滑入-停留-动态退出”强化历史感，动画节奏贴合“翻阅档案”的叙事逻辑
// ==============================================================


// ==============================================================
// 引入外部工具包（复用核心功能）
// 包含交互状态判断、动画工具和燃烧效果（虽未用燃烧，但为扩展预留）
// ==============================================================
Includes = {
    "buttonstate.fxh"        // 按钮状态逻辑（判断按下/悬停，支持交互反馈）
    "sprite_animation.fxh"   // 精灵动画函数（提供基础动画工具，如旋转UV）
    "/intros/saf/burn.fxh"   // 燃烧效果工具（预留，可扩展为照片烧毁等特效）
}


// ==============================================================
// 像素着色器采样器（Samplers）：定义纹理读取规则
// 针对照片优化，确保历史图片的细节清晰（如人物面部、场景纹理）
// ==============================================================
PixelShader =
{
    Samplers =
    {
        MapTexture =  // 主纹理（照片的实际图像，如历史照片内容）
        {
            Index = 0  // 对应游戏传入的第0张图片（照片原图）
            MagFilter = "Linear"  // 放大时平滑过渡（避免老照片颗粒感模糊）
            MinFilter = "Linear"  // 缩小时平滑过渡
            MipFilter = "None"    // 不启用多级渐远纹理（照片无需远处模糊）
            AddressU = "Clamp"    // 超出范围时拉伸边缘（避免照片重复显示）
            AddressV = "Clamp"
            MipMapLodBias = -0.8  // 微调清晰度（增强老照片的细节，如文字、纹理）
        }
        MaskTexture =  // 动画遮罩1（控制照片局部动态，如边角高亮）
        {
            Index = 1  // 对应第1张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture =  // 动画纹理1（照片的动态效果，如旧照片褪色动画）
        {
            Index = 2  // 对应第2张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"  // 超出范围时重复（适合循环动画，如划痕流动）
            AddressV = "Wrap"
        }
        MaskTexture2 =  // 动画遮罩2（备用遮罩，用于复杂动态分层）
        {
            Index = 3  // 对应第3张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture2 =  // 动画纹理2（第二套动态效果，如颜色渐变）
        {
            Index = 4  // 对应第4张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"
            AddressV = "Wrap"
        }
        // 主遮罩（控制照片的显示形状，如模拟老照片的圆角、撕边效果）
        MaskingTexture =
        {
            Index = 5  // 对应第5张图片
            MagFilter = "Point"  // 点过滤（保留遮罩边缘锐度，如撕边的锯齿感）
            MinFilter = "Point"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
    }
}


// ==============================================================
// 顶点输出结构（VS_OUTPUT）：顶点着色器传递给像素着色器的数据
// 包含位置、纹理坐标，支持动画/遮罩坐标（适配照片的动态效果）
// ==============================================================
VertexStruct VS_OUTPUT
{
    float4  vPosition : PDX_POSITION;  // 像素在屏幕上的最终位置
    float2  vTexCoord : TEXCOORD0;     // 主纹理坐标（读取照片的位置）
@ifdef ANIMATED  // 开启动画时，包含动画纹理坐标（如动态效果位置）
    float4  vAnimatedTexCoord : TEXCOORD1;
@endif
@ifdef MASKING  // 开启遮罩时，包含主遮罩坐标（控制照片显示范围）
    float2  vMaskingTexCoord : TEXCOORD2;
@endif
};


// ==============================================================
// 顶点着色器（VertexShader）：计算照片的位置和基础纹理坐标
// 结构简单，仅负责位置转换和坐标传递（核心动画由像素着色器处理）
// ==============================================================
VertexShader =
{
    MainCode VertexShader
    [[
        VS_OUTPUT main(const VS_INPUT v )
        {
            VS_OUTPUT Out;
            // 计算屏幕位置：通过投影矩阵将3D坐标转为屏幕2D坐标
            Out.vPosition  = mul( WorldViewProjectionMatrix, float4( v.vPosition.xyz, 1 ) );
        
            // 传递主纹理坐标（告诉像素着色器该读取照片的哪个部分）
            Out.vTexCoord = v.vTexCoord;
        
            return Out;
        }
    ]]
}


// ==============================================================
// 像素着色器（PixelShader）：核心逻辑，控制照片的完整生命周期
// 重点：Up状态实现“滑入-停留”，Disable状态实现“抖动-旋转退出”，强化历史照片的叙事感
// ==============================================================
PixelShader =
{
    // 1. 状态：Up（正常显示状态，照片的核心展示流程）
    MainCode PixelShaderUp
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取照片主纹理颜色（初始颜色）
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            
            // 【控制参数1：Offset.x】强制隐藏开关
            // 若Offset.x的整数部分+1等于2，则照片完全透明（不显示）
            float value = floor(Offset.x) + 1.f;  // floor取整数部分（如1.2→1）
            if(value == 2)
            {
                return float4(0,0,0,0);  // 全透明（隐藏）
            }
            
            // 计算动画时间：当前时间(Time) - 动画开始时间(AnimationTime)
            float vTime = Time - AnimationTime;
            
            // 阶段1：<75秒 → 照片完全透明（不显示，等待叠加层等框架元素准备）
            if(vTime < 75)
            {
                return float4(0,0,0,0);
            }
            // 阶段2：75~76秒（1秒窗口）→ 滑入动画（从上方进入视野）
            else if(vTime >= 75 && vTime < 76)
            {
                // 计算偏移后的纹理坐标（仅y方向移动，模拟“从上往下滑入”）
                float2 newTexCoord = v.vTexCoord;
                // cos函数控制偏移量：75秒时偏移1单位（完全在屏幕外上方），76秒时偏移0（完全进入）
                // 原理：(vTime-75)从0→1，1-(vTime-75)从1→0，cos(1.5f*该值)从cos(1.5)≈0→cos(0)=1，最终偏移量从1→0
                newTexCoord.y -= 1.f - cos((1.f - (vTime - 75)) * 1.5f);
                
                // 限制显示范围：超出照片纹理范围的部分隐藏（避免滑入时显示边缘外的内容）
                if(newTexCoord.y > 1 || newTexCoord.y < 0)
                {
                    return float4(0,0,0,0);
                }
                // 读取偏移后的照片颜色（实现滑入效果）
                OutColor = tex2D( MapTexture, newTexCoord );
            }
            // 阶段4：>88.5秒 → 照片完全透明（退出显示，为后续元素让路）
            else if(vTime > 88.5)
            {
                return float4(0,0,0,0);
            }
            // 阶段3：76~88.5秒（约12.5秒窗口）→ 稳定显示（供玩家观察照片内容）
            
            return OutColor;
        }
    ]]

    // 2. 状态：Down（按下状态，照片变暗效果）
    MainCode PixelShaderDown
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取照片主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                    
        // 开启动画时，混合动画纹理（如按下时照片局部变暗，模拟“按压纸质照片”的质感）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度（如仅显示照片的有效内容区域）
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;  // 遮罩透明区域让对应部分消失（如照片边框外）
        #endif
            
            // 用游戏传入的Color参数调整照片色调（按下时整体变暗，增强交互反馈）
            OutColor *= Color;

            // 按下时的亮度衰减计算
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 16 );  // 限制值0~1
            vTime *= vTime;  // 平方运算让变化更平滑（先快后慢）
            vTime = 0.9*0.9 - vTime;  // 反向计算衰减值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（降低亮度）
            OutColor.rgb -= ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 降低RGB亮度

            return OutColor;
        }
    ]]

    // 3. 状态：Disable（禁用状态，照片的退出动画：抖动→旋转消失）
    MainCode PixelShaderDisable
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取照片主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            
            // 【控制参数：Offset.x】强制隐藏（同Up状态）
            float value = floor(Offset.x) + 1.f;
            if(value == 2)
            {
                return float4(0,0,0,0);
            }
            
            // 计算动画时间：当前时间 - 动画开始时间
            float vTime = Time - AnimationTime;
            
            // 阶段1：<88.5秒 → 完全透明（不显示，等待Up状态结束）
            if(vTime < 88.5)
            {
                return float4(0,0,0,0);
            }
            // 阶段2：94.5~96.5秒（2秒窗口）→ 抖动动画（模拟“照片被拿走前的颤抖”）
            else if(vTime >= 94.5 && vTime < 96.5)
            {
                // 用sin函数生成快速抖动偏移（频率100次/秒，模拟高频颤抖）
                float shake = sin(vTime * 100.f);  // sin值范围-1~1，控制抖动方向
                float2 shakeUV = v.vTexCoord + 0.01f * shake;  // 抖动幅度0.01（微小偏移）
                
                // 限制显示范围：超出照片纹理范围的部分隐藏
                if(shakeUV.x < 0 || shakeUV.x > 1 || shakeUV.y < 0 || shakeUV.y > 1)
                {
                    return float4(0,0,0,0);
                }
                // 读取抖动后的照片颜色（实现颤抖效果）
                OutColor = tex2D( MapTexture, (v.vTexCoord + 0.01f * shake) );
            }
            // 阶段3：96.5~98秒（1.5秒窗口）→ 旋转退出（从右下角旋转消失）
            else if(vTime >= 96.5 && vTime < 98)
            {
                float2 pivot = float2(1.f, 1.f);  // 旋转支点（照片右下角，模拟“从角落翻走”）
                float speed  = 2.5f;  // 旋转速度（2.5弧度/秒，1.5秒内旋转约3.75弧度≈215度）

                // 计算旋转角度：从0开始随时间增加（96.5秒时0，98秒时约3.75弧度）
                float angle = (vTime - 96.5) * speed;

                // 调用旋转UV工具函数（来自sprite_animation.fxh），计算旋转后的纹理坐标
                float2 rotUV = RotateUV(v.vTexCoord, pivot, angle);
            
                // 限制显示范围：旋转后超出照片纹理范围的部分隐藏（模拟“翻出屏幕”）
                if(rotUV.x < 0 || rotUV.x > 1 || rotUV.y < 0 || rotUV.y > 1)
                {
                    return float4(0,0,0,0);
                }

                // 读取旋转后的照片颜色（实现翻转动画）
                OutColor = tex2D(MapTexture, rotUV);
            }
            // 阶段4：≥98秒 → 完全透明（退出完成）
            else if(vTime >= 96.5)
            {
                return float4(0,0,0,0);
            }
            
            return OutColor;
        }	
    ]]

    // 4. 状态：Over（悬停状态，照片变亮效果）
    MainCode PixelShaderOver
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取照片主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                
        // 开启动画时，混合动画纹理（如悬停时照片边缘高亮，提示可交互）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;
        #endif

            // 用Color参数调整照片色调（悬停时整体变亮，增强交互反馈）
            OutColor *= Color;
            
            // 悬停时的亮度增强计算
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 4 );  // 变化较慢（系数4）
            vTime *= vTime;  // 平方运算让变化平滑
            vTime = 0.9*0.9 - vTime;  // 反向计算增强值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（提升亮度）
            OutColor.rgb += ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 增加RGB亮度

            return OutColor;
        }
    ]]
}


// ==============================================================
// 混合状态（BlendState）：控制照片与下层元素的叠加方式
// 启用混合确保照片的半透明区域（如老照片的褪色边缘、圆角）自然叠加
// ==============================================================
BlendState BlendState
{
    BlendEnable = yes  // 启用混合（支持照片半透明效果）
    SourceBlend = "src_alpha"  // 自身颜色占比=自身透明度
    DestBlend = "inv_src_alpha"  // 下层颜色占比=1-自身透明度
    // 最终颜色 = 照片颜色*透明度 + 下层颜色*(1-透明度)（确保照片与背景框架自然融合）
}


// ==============================================================
// 效果定义（Effect）：组合顶点和像素着色器，供游戏调用
// 游戏根据照片的状态（正常/按下/禁用/悬停）自动切换
// ==============================================================
Effect Up  // 正常状态：75~88.5秒，1秒滑入→12.5秒稳定展示→自动隐藏
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderUp"
}

Effect Down  // 按下状态：照片变暗（模拟按压纸质照片的质感）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDown"
}

Effect Disable  // 禁用状态：88.5秒后，2秒抖动→1.5秒旋转→完全消失（退出动画）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDisable"
}

Effect Over  // 悬停状态：照片变亮（提示可交互，如查看照片详情）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderOver"
}