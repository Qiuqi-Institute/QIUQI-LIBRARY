// ==============================================================
// 文件名：background_tile_lower.shader
// 作用：控制钢铁雄心4中"下层背景瓦片"的显示效果和动态动画
// 适用场景：游戏底层背景元素（如下层地图瓦片、基础背景纹理），作为上层元素的承载框架
// 核心功能：在较长时间窗口（0~120.5秒）内提供稳定的底层视觉支撑，包含：
//          - 初始黑色渐显（0~2秒，从全黑到显示完整背景）
//          - 稳定展示（2~110.5秒，约108.5秒作为上层元素的背景底座）
//          - 后期燃烧退场（110.5~120.5秒，10秒从角落向外燃烧消失）
//          - 交互状态反馈（按下变暗、悬停变亮，适配用户操作）
// 与其他元素的差异：作为最底层背景，存在时间最长（贯穿流程前中期），动画聚焦"平稳过渡+最终退场"，不抢占上层内容注意力
// ==============================================================


// ==============================================================
// 引入外部工具包（复用通用功能）
// 包含交互状态判断、精灵动画工具和燃烧效果（核心退场动画依赖）
// ==============================================================
Includes = {
    "buttonstate.fxh"      // 按钮状态逻辑（判断按下/悬停，提供交互反馈基础）
    "sprite_animation.fxh" // 精灵动画函数（支持基础动态效果，如纹理混合）
    "/intros/saf/burn.fxh" // 燃烧效果工具（实现后期从角落向外燃烧的退场动画）
}


// ==============================================================
// 像素着色器采样器（Samplers）：定义纹理读取规则
// 针对底层背景优化，确保大尺寸瓦片显示平滑（无明显拉伸或模糊）
// ==============================================================
PixelShader =
{
    Samplers =
    {
        MapTexture =  // 主纹理（下层背景瓦片的基础图像，如地图纹理、底色）
        {
            Index = 0  // 对应游戏传入的第0张图片（背景瓦片原图）
            MagFilter = "Linear"  // 放大时平滑过渡（避免大尺寸背景出现锯齿）
            MinFilter = "Linear"  // 缩小时平滑过渡
            MipFilter = "None"    // 不启用多级渐远纹理（底层背景无需远处模糊）
            AddressU = "Clamp"    // 超出范围时拉伸边缘（避免背景重复错位）
            AddressV = "Clamp"
            MipMapLodBias = -0.8  // 微调清晰度（增强背景细节，如纹理纹路）
        }
        MaskTexture =  // 动画遮罩1（控制背景局部动态，如局部高亮闪烁）
        {
            Index = 1  // 对应第1张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture =  // 动画纹理1（背景的动态效果，如缓慢流动的纹理）
        {
            Index = 2  // 对应第2张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"  // 超出范围时重复（适合循环动画，如纹理流动）
            AddressV = "Wrap"
        }
        MaskTexture2 =  // 动画遮罩2（备用遮罩，用于复杂分层动态）
        {
            Index = 3  // 对应第3张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture2 =  // 动画纹理2（第二套动态效果，如颜色渐变）
        {
            Index = 4  // 对应第4张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"
            AddressV = "Wrap"
        }
        // 主遮罩（控制背景的显示范围，如仅显示屏幕内的瓦片区域）
        MaskingTexture =
        {
            Index = 5  // 对应第5张图片
            MagFilter = "Point"  // 点过滤（保留遮罩边缘锐度，确保背景边界清晰）
            MinFilter = "Point"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
    }
}


// ==============================================================
// 顶点输出结构（VS_OUTPUT）：顶点着色器传递给像素着色器的数据
// 包含位置、纹理坐标，支持条件编译的动画/遮罩坐标（适配动态效果）
// ==============================================================
VertexStruct VS_OUTPUT
{
    float4  vPosition : PDX_POSITION;  // 像素在屏幕上的最终位置
    float2  vTexCoord : TEXCOORD0;     // 主纹理坐标（读取背景瓦片的位置）
@ifdef ANIMATED  // 开启动画时，包含动画纹理坐标（动态效果位置）
    float4  vAnimatedTexCoord : TEXCOORD1;
@endif
@ifdef MASKING  // 开启遮罩时，包含主遮罩坐标（控制背景显示范围）
    float2  vMaskingTexCoord : TEXCOORD2;
@endif
};


// ==============================================================
// 顶点着色器（VertexShader）：计算背景瓦片的位置和基础纹理坐标
// 结构简单，仅负责位置转换和坐标传递（核心动画由像素着色器处理）
// ==============================================================
VertexShader =
{
    MainCode VertexShader
    [[
        VS_OUTPUT main(const VS_INPUT v )
        {
            VS_OUTPUT Out;
            // 计算屏幕位置：通过投影矩阵将3D坐标转为屏幕2D坐标
            Out.vPosition  = mul( WorldViewProjectionMatrix, float4( v.vPosition.xyz, 1 ) );
        
            // 传递主纹理坐标（告诉像素着色器该读取背景的哪个部分）
            Out.vTexCoord = v.vTexCoord;
        
            return Out;
        }
    ]]
}


// ==============================================================
// 像素着色器（PixelShader）：核心逻辑，控制背景瓦片的完整生命周期
// 重点：Up/Disable状态实现"初始渐显-稳定支撑-燃烧退场"，配合上层元素节奏
// ==============================================================
PixelShader =
{
    // 1. 状态：Up（正常显示状态，背景瓦片的核心生命周期）
    MainCode PixelShaderUp
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取背景主纹理颜色（基础背景色）
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            
            // 【控制参数1：Offset.x】强制隐藏开关
            // 若Offset.x的整数部分+1等于2，则背景完全透明（不显示）
            float value = floor(Offset.x) + 1.f;  // floor取整数部分（如2.3→2）
            if(value == 2)
            {
                return float4(0,0,0,0);  // 全透明（隐藏）
            }
            
            // 计算动画时间：当前时间(Time) - 动画开始时间(AnimationTime)
            float vTime = Time - AnimationTime;
            
            // 阶段1：0~2秒 → 初始渐显（从全黑过渡到显示背景）
            if(vTime < 2.f)
            {
                OutColor = float4(0,0,0,1);  // 初始为黑色（覆盖屏幕）
                OutColor.a = vTime * 0.5f;   // 透明度随时间线性增加（2秒时完全显示背景）
                // 效果：模拟"场景逐渐亮起"，为上层元素入场铺垫
            }
            // 阶段3：110.5~120.5秒 → 燃烧退场（从右上角向外燃烧消失）
            else if(vTime > 110.5f && vTime < 120.5f)
            {
                // 燃烧效果参数设置（调用burn.fxh中的工具函数）
                float4 colour = float4(0,0,0,1);  // 燃烧区域的基础色（黑色）
                float2 BurnCenter = float2(1.f, 0.f);  // 燃烧中心（右上角：x=1最右，y=0最上）
                float Aspect = 1.0f;  // 宽高比（保持背景比例，无拉伸）
                float cTime = vTime - 110.5f;  // 燃烧动画本地时间（从0开始计时）
                float Radius0 = 0.0f;  // 初始燃烧半径（从点开始）
                float Speed = 0.13;    // 燃烧扩展速度（0.13单位/秒，10秒内覆盖全屏）
                float JagAmp = 0.01f;  // 燃烧边缘锯齿幅度（轻微不规则，模拟火焰边缘）
                float Freq = 4.f;      // 锯齿频率（中等密度，边缘细节适中）
                float Flow = 0.8f;     // 锯齿流动速度（模拟火焰飘动效果）
                float EdgeWidth = 0.01f; // 燃烧边缘过渡宽度（较窄，边缘清晰）
                float RimWidth = 0.001f; // 火焰光晕宽度（几乎无，避免抢镜）
                float RimSigma = 0.005f; // 光晕模糊度（轻微模糊，增强真实感）
                float HeatAmp = 0.003f;  // 热扭曲幅度（轻微扭曲背景，模拟热浪）
                float3 EmberColor = float3(0.8, 0.6, 0.4); // 火焰颜色（浅橙褐色，贴近自然火焰）
                float EmberBoost = 0.05f; // 火焰亮度（较暗，不掩盖上层元素退场）
                
                // 调用燃烧效果函数，返回燃烧后的颜色
                float4 burn = ApplyBurnColour(v.vTexCoord, colour, BurnCenter, Aspect, cTime, 
                                             Radius0, Speed, JagAmp, Freq, Flow, 
                                             EdgeWidth, RimWidth, RimSigma, HeatAmp, 
                                             EmberColor, EmberBoost);
                return burn;  // 显示燃烧效果，背景逐渐被黑色覆盖
            }
            // 阶段4：>120.5秒 → 完全透明（退场完成，为后续场景让路）
            else if(vTime > 120.5f)
            {
                return float4(0,0,0,0);
            }
            
            // 阶段2：2~110.5秒 → 稳定展示（作为上层元素的底层背景，无动画干扰）
            return OutColor;
        }
    ]]

    // 2. 状态：Down（按下状态，背景瓦片变暗效果）
    MainCode PixelShaderDown
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取背景主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                    
        // 开启动画时，混合动画纹理（如按下时局部背景变暗，增强交互反馈）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度（限制背景显示范围）
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;  // 遮罩透明区域让背景对应部分消失
        #endif
            
            // 用游戏传入的Color参数调整背景色调（按下时整体变暗）
            OutColor *= Color;

            // 按下时的亮度衰减计算（随时间变暗，强化交互反馈）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 16 );  // 限制值0~1
            vTime *= vTime;  // 平方运算让变化更平滑（先快后慢）
            vTime = 0.9*0.9 - vTime;  // 反向计算衰减值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（降低亮度）
            OutColor.rgb -= ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 降低RGB亮度

            return OutColor;
        }
    ]]

    // 3. 状态：Disable（禁用状态，背景瓦片的左侧燃烧退场）
    MainCode PixelShaderDisable
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取背景主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            
            // 【控制参数：Offset.x】强制隐藏（同Up状态）
            float value = floor(Offset.x) + 1.f;
            if(value == 2)
            {
                return float4(0,0,0,0);
            }
            
            // 计算动画时间：当前时间 - 动画开始时间
            float vTime = Time - AnimationTime;
            
            // 阶段1：0~2秒 → 初始渐显（同Up状态，确保背景同步入场）
            if(vTime < 2.f)
            {
                OutColor = float4(0,0,0,1);
                OutColor.a = vTime * 0.5f;
            }
            // 阶段3：110.5~120.5秒 → 燃烧退场（从左上角向外燃烧消失）
            else if(vTime > 110.5f && vTime < 120.5f)
            {
                // 燃烧效果参数（与Up状态类似，但燃烧中心不同）
                float4 colour = float4(0,0,0,1);  // 基础黑色
                float2 BurnCenter = float2(0.f, 0.f);  // 燃烧中心（左上角：x=0最左，y=0最上）
                float Aspect = 1.0f;  // 宽高比
                float cTime = vTime - 110.5f;  // 燃烧本地时间
                float Radius0 = 0.0f;  // 初始半径
                float Speed = 0.13f;   // 扩展速度（与Up相同，确保两侧同步燃烧）
                float JagAmp = 0.01f;  // 锯齿幅度
                float Freq = 4.f;      // 锯齿频率
                float Flow = 0.8f;     // 流动速度
                float EdgeWidth = 0.01f; // 边缘宽度
                float RimWidth = 0.001f; // 光晕宽度
                float RimSigma = 0.005f; // 光晕模糊度
                float HeatAmp = 0.003f;  // 热扭曲幅度
                float3 EmberColor = float3(0.8, 0.6, 0.4); // 火焰颜色
                float EmberBoost = 0.05f; // 火焰亮度
                
                // 调用燃烧效果函数（从左上角燃烧，与Up状态的右上角形成对称退场）
                float4 burn = ApplyBurnColour(v.vTexCoord, colour, BurnCenter, Aspect, cTime, 
                                             Radius0, Speed, JagAmp, Freq, Flow, 
                                             EdgeWidth, RimWidth, RimSigma, HeatAmp, 
                                             EmberColor, EmberBoost);
                return burn;
            }
            // 阶段4：>120.5秒 → 完全透明（退场完成）
            else if(vTime > 120.5f)
            {
                return float4(0,0,0,0);
            }
            
            // 阶段2：2~110.5秒 → 稳定展示（同Up状态，作为底层支撑）
            return OutColor;
        }	
    ]]

    // 4. 状态：Over（悬停状态，背景瓦片变亮效果）
    MainCode PixelShaderOver
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取背景主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                
        // 开启动画时，混合动画纹理（如悬停时局部背景变亮，提示可交互）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;
        #endif

            // 用Color参数调整背景色调（悬停时整体变亮）
            OutColor *= Color;
            
            // 悬停时的亮度增强计算（随时间变亮，突出交互反馈）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 4 );  // 变化较慢（系数4）
            vTime *= vTime;  // 平方运算让变化平滑
            vTime = 0.9*0.9 - vTime;  // 反向计算增强值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（提升亮度）
            OutColor.rgb += ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 增加RGB亮度

            return OutColor;
        }
    ]]
}


// ==============================================================
// 混合状态（BlendState）：控制背景瓦片与下层/上层元素的叠加方式
// 启用混合确保背景的半透明区域（如边缘过渡、燃烧效果）自然融合
// ==============================================================
BlendState BlendState
{
    BlendEnable = yes  // 启用混合（支持透明效果）
    SourceBlend = "src_alpha"  // 自身颜色占比=自身透明度
    DestBlend = "inv_src_alpha"  // 下层颜色占比=1-自身透明度
    // 最终颜色 = 背景颜色*透明度 + 下层/上层颜色*(1-透明度)（确保背景与其他元素自然衔接）
}


// ==============================================================
// 效果定义（Effect）：组合顶点和像素着色器，供游戏调用
// 游戏根据背景瓦片的状态（正常/按下/禁用/悬停）自动切换
// ==============================================================
Effect Up  // 正常状态：0~120.5秒，2秒渐显→108.5秒稳定→10秒右上角燃烧退场
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderUp"
}

Effect Down  // 按下状态：背景瓦片变暗（增强交互反馈）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDown"
}

Effect Disable  // 禁用状态：0~120.5秒，2秒渐显→108.5秒稳定→10秒左上角燃烧退场
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDisable"
}

Effect Over  // 悬停状态：背景瓦片变亮（突出交互反馈）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderOver"
}