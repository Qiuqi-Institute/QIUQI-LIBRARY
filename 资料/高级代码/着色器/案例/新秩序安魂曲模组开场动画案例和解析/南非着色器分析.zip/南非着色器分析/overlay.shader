// ==============================================================
// 文件名：overlay.shader
// 作用：控制钢铁雄心4中"叠加层元素"的显示效果和动态动画
// 适用场景：游戏中的装饰性边框、背景叠加层、框架类元素（如界面边框、场景装饰框）
// 核心功能：根据状态和时间呈现叠加层的完整生命周期，包含：
//          - 早期渐入显示（10~12秒）
//          - 长期稳定展示（12~110.5秒）
//          - 最终燃烧消失（110.5~120.5秒）
//          - 按下/悬停时的亮度变化（保持交互反馈）
// 与其他元素的差异：作为基础叠加层，出现最早、存续时间最长，以燃烧效果结束，强化场景收尾仪式感
// ==============================================================


// ==============================================================
// 引入外部工具包（复用核心功能）
// 重点引入燃烧效果工具，用于叠加层的最终消失动画
// ==============================================================
Includes = {
    "buttonstate.fxh"        // 按钮状态逻辑（按下/悬停判断）
    "sprite_animation.fxh"   // 精灵动画函数（支持叠加层基础动态）
    "/intros/saf/burn.fxh"   // 燃烧效果工具（核心：实现叠加层燃烧消失效果）
}


// ==============================================================
// 像素着色器采样器（Samplers）：定义纹理读取规则
// 针对叠加层优化，确保边框/框架的边缘清晰、细节完整（尤其燃烧时）
// ==============================================================
PixelShader =
{
    Samplers =
    {
        MapTexture =  // 主纹理（叠加层的基础图像，如边框、装饰框架）
        {
            Index = 0  // 对应游戏传入的第0张图片（叠加层原图）
            MagFilter = "Linear"  // 放大时平滑过渡（避免边框边缘锯齿）
            MinFilter = "Linear"  // 缩小时平滑过渡
            MipFilter = "None"    // 不启用多级渐远纹理（叠加层无需远处模糊）
            AddressU = "Clamp"    // 超出范围时拉伸边缘（避免边框重复错位）
            AddressV = "Clamp"
            MipMapLodBias = -0.8  // 微调清晰度（增强边框细节，如花纹、纹理）
        }
        MaskTexture =  // 动画遮罩1（控制叠加层局部动态，如部分区域高亮）
        {
            Index = 1  // 对应第1张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture =  // 动画纹理1（叠加层的动态效果，如边缘闪烁）
        {
            Index = 2  // 对应第2张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"  // 超出范围时重复（适合循环动画，如光效流动）
            AddressV = "Wrap"
        }
        MaskTexture2 =  // 动画遮罩2（备用遮罩，用于复杂动态分层）
        {
            Index = 3  // 对应第3张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture2 =  // 动画纹理2（第二套动态效果，如颜色渐变）
        {
            Index = 4  // 对应第4张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"
            AddressV = "Wrap"
        }
        // 主遮罩（控制叠加层的整体可见形状，如仅显示边框内框区域）
        MaskingTexture =
        {
            Index = 5  // 对应第5张图片
            MagFilter = "Point"  // 点过滤（保留边框边缘锐度，避免模糊）
            MinFilter = "Point"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
    }
}


// ==============================================================
// 顶点输出结构（VS_OUTPUT）：顶点着色器传递给像素着色器的数据
// 包含位置、纹理坐标，支持条件编译的动画/遮罩坐标（适配叠加层动态）
// ==============================================================
VertexStruct VS_OUTPUT
{
    float4  vPosition : PDX_POSITION;  // 像素在屏幕上的最终位置
    float2  vTexCoord : TEXCOORD0;     // 主纹理坐标（读取叠加层的位置）
@ifdef ANIMATED  // 开启动画时，包含动画纹理坐标（如动态效果位置）
    float4  vAnimatedTexCoord : TEXCOORD1;
@endif
@ifdef MASKING  // 开启遮罩时，包含主遮罩坐标（控制叠加层显示范围）
    float2  vMaskingTexCoord : TEXCOORD2;
@endif
};


// ==============================================================
// 顶点着色器（VertexShader）：计算叠加层的位置和基础纹理坐标
// 结构简单，仅负责位置转换和纹理坐标传递（动态效果由像素着色器处理）
// ==============================================================
VertexShader =
{
    MainCode VertexShader
    [[
        VS_OUTPUT main(const VS_INPUT v )
        {
            VS_OUTPUT Out;
            // 计算屏幕位置：通过投影矩阵将3D坐标转为屏幕2D坐标
            Out.vPosition  = mul( WorldViewProjectionMatrix, float4( v.vPosition.xyz, 1 ) );
        
            // 传递主纹理坐标（告诉像素着色器该读取叠加层的哪个部分）
            Out.vTexCoord = v.vTexCoord;
        
            return Out;
        }
    ]]
}


// ==============================================================
// 像素着色器（PixelShader）：核心逻辑，控制叠加层的完整生命周期
// 重点：Up/Disable状态共享"渐入-稳定-燃烧消失"流程，是所有元素中存续时间最长的
// ==============================================================
PixelShader =
{
    // 1. 状态：Up（正常显示状态，叠加层的完整生命周期）
    MainCode PixelShaderUp
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取叠加层主纹理颜色（初始颜色）
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            
            // 【控制参数1：Offset.x】强制隐藏开关
            // 若Offset.x的整数部分+1等于2，则叠加层完全透明（不显示）
            float value = floor(Offset.x) + 1.f;  // floor取整数部分（如1.3→1）
            if(value == 2)
            {
                return float4(0,0,0,0);  // 全透明（隐藏）
            }
            
            // 计算动画时间：当前时间(Time) - 动画开始时间(AnimationTime)
            float vTime = Time - AnimationTime;
            
            // 阶段1：<10秒 → 叠加层完全透明（不显示，等待其他元素准备）
            if(vTime < 10.f)
            {
                return float4(0,0,0,0);
            }
            // 阶段2：10~12秒（2秒窗口）→ 渐入（透明度从0→1）
            else if(vTime > 10.f && vTime <= 12.f)
            {
                // 透明度 = (当前时间-10) * 0.5 → 10秒时0，12秒时1（线性递增）
                OutColor.a *= (vTime - 10.f) * 0.5f;
            }
            // 阶段4：110.5~120.5秒（10秒窗口）→ 燃烧消失（核心动画）
            else if(vTime > 110.5f && vTime < 120.5f)
            {
                // 燃烧效果参数配置（控制火焰的形态、颜色、扩散速度）
                float4 colour = float4(0,0,0,1);  // 基础火焰颜色（黑色背景）
                float2 BurnCenter = float2(0.5f, 0.5f);  // 燃烧中心点（叠加层中心）
                float Aspect = 1.8f;  // 宽高比适配（确保火焰在不同尺寸下比例正确）
                float cTime = vTime - 110.5f;  // 燃烧动画本地时间（从0开始）
                float Radius0 = 0.0f;  // 初始燃烧半径（从中心开始）
                float Speed = 0.25f;  // 燃烧扩散速度（数值越大扩散越快）
                float JagAmp = 0.01f;  // 火焰边缘锯齿幅度（控制火焰粗糙感）
                float Freq = 4.f;  // 火焰边缘锯齿频率（数值越大锯齿越密集）
                float Flow = 0.8f;  // 火焰流动感（模拟火焰向上飘动的动态）
                float EdgeWidth = 0.01f;  // 火焰边缘宽度（控制火焰过渡带）
                float RimWidth = 0.001f;  // 火焰亮边宽度（强化火焰轮廓）
                float RimSigma = 0.005f;  // 亮边模糊度（让亮边更自然）
                float HeatAmp = 0.003f;  // 热扰动幅度（模拟火焰的不规则跳动）
                float3 EmberColor = float3(0.8, 0.6, 0.4);  // 火星颜色（橙黄色调）
                float EmberBoost = 0.05f;  // 火星亮度增强（让火星更明显）
                
                // 调用燃烧效果函数（来自burn.fxh），生成燃烧动画颜色
                float4 burn = ApplyBurnColour(v.vTexCoord, OutColor, BurnCenter, Aspect, cTime, 
                                             Radius0, Speed, JagAmp, Freq, Flow, EdgeWidth, 
                                             RimWidth, RimSigma, HeatAmp, EmberColor, EmberBoost);
                return burn;  // 返回燃烧效果颜色
            }
            // 阶段5：>120.5秒 → 叠加层完全透明（燃烧结束，消失）
            else if(vTime > 120.5f)
            {
                return float4(0,0,0,0);
            }
            // 阶段3：12~110.5秒（约98.5秒窗口）→ 稳定显示（无动态，作为基础框架）
            
            return OutColor;
        }
    ]]

    // 2. 状态：Down（按下状态，叠加层变暗效果）
    MainCode PixelShaderDown
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取叠加层主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                    
        // 开启动画时，混合动画纹理（如按下时叠加层局部变暗）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度（如仅显示边框核心区域）
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;  // 遮罩透明区域让对应部分消失
        #endif
            
            // 用游戏传入的Color参数调整叠加层色调（按下时整体变暗）
            OutColor *= Color;

            // 按下时的亮度衰减（随时间变暗，增强交互反馈）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 16 );  // 限制值0~1
            vTime *= vTime;  // 平方运算让变化更平滑（先快后慢）
            vTime = 0.9*0.9 - vTime;  // 反向计算衰减值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（降低亮度）
            OutColor.rgb -= ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 降低RGB亮度

            return OutColor;
        }
    ]]

    // 3. 状态：Disable（禁用状态，叠加层的燃烧消失流程）
    MainCode PixelShaderDisable
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取叠加层主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            
            // 【控制参数：Offset.x】强制隐藏（同Up状态）
            float value = floor(Offset.x) + 1.f;
            if(value == 2)
            {
                return float4(0,0,0,0);
            }
            
            // 计算动画时间：当前时间 - 动画开始时间
            float vTime = Time - AnimationTime;
            
            // 阶段1：<10秒 → 不显示
            if(vTime < 10.f)
            {
                return float4(0,0,0,0);
            }
            // 阶段2：10~12秒 → 渐入（同Up状态，确保禁用状态下初始显示一致）
            else if(vTime > 10.f && vTime <= 12.f)
            {
                OutColor.a *= (vTime - 10.f) * 0.5f;
            }
            // 阶段4：110.5~120.5秒 → 燃烧消失（与Up状态完全一致的燃烧效果）
            else if(vTime > 110.5f && vTime < 120.5f)
            {
                // 燃烧参数与Up状态相同（确保燃烧效果一致性）
                float4 colour = float4(0,0,0,1);
                float2 BurnCenter = float2(0.5f, 0.5f);
                float Aspect = 1.8f;
                float cTime = vTime - 110.5f;
                float Radius0 = 0.0f;
                float Speed = 0.25f;
                float JagAmp = 0.01f;
                float Freq = 4.f;
                float Flow = 0.8f;
                float EdgeWidth = 0.01f;
                float RimWidth = 0.001f;
                float RimSigma = 0.005f;
                float HeatAmp = 0.003f;
                float3 EmberColor = float3(0.8, 0.6, 0.4);
                float EmberBoost = 0.05f;
                
                float4 burn = ApplyBurnColour(v.vTexCoord, OutColor, BurnCenter, Aspect, cTime, 
                                             Radius0, Speed, JagAmp, Freq, Flow, EdgeWidth, 
                                             RimWidth, RimSigma, HeatAmp, EmberColor, EmberBoost);
                return burn;
            }
            // 阶段5：>120.5秒 → 消失
            else if(vTime > 120.5f)
            {
                return float4(0,0,0,0);
            }
            // 阶段3：12~110.5秒 → 稳定显示（禁用状态下仍作为基础框架存在）
            
            return OutColor;
        }	
    ]]

    // 4. 状态：Over（悬停状态，叠加层变亮效果）
    MainCode PixelShaderOver
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取叠加层主纹理颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                
        // 开启动画时，混合动画纹理（如悬停时叠加层边缘高亮）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;
        #endif

            // 用Color参数调整叠加层色调（悬停时整体变亮）
            OutColor *= Color;
            
            // 悬停时的亮度增强（随时间变亮，突出交互反馈）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 4 );  // 变化较慢（系数4）
            vTime *= vTime;  // 平方运算让变化平滑
            vTime = 0.9*0.9 - vTime;  // 反向计算增强值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（提升亮度）
            OutColor.rgb += ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 增加RGB亮度

            return OutColor;
        }
    ]]
}


// ==============================================================
// 混合状态（BlendState）：控制叠加层与下层元素的叠加方式
// 启用混合确保叠加层的半透明区域（如边框边缘、花纹）正确叠加，不遮挡下层内容
// ==============================================================
BlendState BlendState
{
    BlendEnable = yes  // 启用混合（支持叠加层半透明效果）
    SourceBlend = "src_alpha"  // 自身颜色占比=自身透明度
    DestBlend = "inv_src_alpha"  // 下层颜色占比=1-自身透明度
    // 最终颜色 = 叠加层颜色*透明度 + 下层颜色*(1-透明度)（确保叠加层与背景自然融合）
}


// ==============================================================
// 效果定义（Effect）：组合顶点和像素着色器，供游戏调用
// 游戏根据叠加层的状态（正常/按下/禁用/悬停）自动切换
// ==============================================================
Effect Up  // 正常状态：10~120.5秒，2秒渐入→98.5秒稳定→10秒燃烧消失
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderUp"
}

Effect Down  // 按下状态：叠加层变暗
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDown"
}

Effect Disable  // 禁用状态：与Up状态共享生命周期（渐入-稳定-燃烧消失）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDisable"
}

Effect Over  // 悬停状态：叠加层变亮
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderOver"
}