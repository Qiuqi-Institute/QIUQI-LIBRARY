// ==============================================================
// 文件名：borders_full.shader
// 作用：控制钢铁雄心4中"完整边框元素"的显示效果与动态动画
// 适用场景：游戏中包围核心区域的边框（如地图边缘框线、界面分区边框、功能区域轮廓线等）
// 核心功能：通过严格的时间控制和独特的燃烧特效，实现边框的阶段性显示，包括：
//          - 正常状态：仅在12~34秒窗口内可见（精准匹配核心内容的展示周期）
//          - 禁用状态：双中心叠加燃烧效果（从边框中上部和中下部同时扩散，强化退场仪式感）
//          - 交互反馈：按下时变暗、悬停时变亮（与其他背景元素保持操作反馈一致性）
// 与其他背景元素的核心差异：
//          1. 时间约束更严格：正常状态仅22秒可见窗口（12~34秒），其他时间完全隐藏；
//          2. 燃烧特效独特：禁用状态采用"双中心叠加燃烧"（上下各一），而非单一中心/角落；
//          3. 功能定位：作为"区域界定者"，显示时机与核心内容（如地图、界面组件）的活跃期强绑定。
// ==============================================================


// ==============================================================
// 引入外部工具包（复用通用功能，支撑边框的动画与交互）
// ==============================================================
Includes = {
    "buttonstate.fxh"      // 按钮状态逻辑（判断按下/悬停状态，支撑基础交互反馈）
    "sprite_animation.fxh" // 精灵动画函数（提供纹理混合、序列帧播放等工具，用于边框动态效果）
    "/intros/saf/burn.fxh" // 燃烧效果工具（核心依赖，实现禁用状态的双中心燃烧特效）
}


// ==============================================================
// 像素着色器采样器（Samplers）：定义纹理读取规则
// 结构与其他背景元素一致，确保全场景纹理处理风格统一，重点优化边框线条清晰度
// ==============================================================
PixelShader =
{
    Samplers =
    {
        MapTexture =  // 主纹理（边框的基础图像，如线条、花纹、装饰性轮廓）
        {
            Index = 0  // 对应游戏传入的第0张图片（边框原始图像）
            MagFilter = "Linear"  // 放大时线性过滤（避免边框线条出现锯齿，保持平滑）
            MinFilter = "Linear"  // 缩小时线性过滤（确保小尺寸边框依然清晰）
            MipFilter = "None"    // 不启用多级渐远纹理（边框无需因距离远而模糊）
            AddressU = "Clamp"    // 水平方向超出范围时拉伸边缘（避免边框重复错位）
            AddressV = "Clamp"    // 垂直方向同上
            MipMapLodBias = -0.8  // 微调纹理细节（轻微提升清晰度，强化边框花纹细节）
        }
        MaskTexture =  // 动画遮罩1（控制边框局部动态区域，如部分边框的闪烁、流动范围）
        {
            Index = 1  // 对应第1张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture =  // 动画纹理1（边框的动态效果，如流动光效、脉冲闪烁等）
        {
            Index = 2  // 对应第2张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"  // 水平方向超出范围时重复（适合循环动画，如光效沿边框流动）
            AddressV = "Wrap"  // 垂直方向同上
        }
        MaskTexture2 =  // 动画遮罩2（备用遮罩，用于复杂边框的分层动画控制）
        {
            Index = 3  // 对应第3张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
        AnimatedTexture2 =  // 动画纹理2（第二套动态效果，如边框颜色渐变、局部高亮）
        {
            Index = 4  // 对应第4张图片
            MagFilter = "Linear"
            MinFilter = "Linear"
            MipFilter = "None"
            AddressU = "Wrap"
            AddressV = "Wrap"
        }
        // 主遮罩（控制边框整体可见形状，如仅显示特定区域的边框、裁剪多余部分）
        MaskingTexture =
        {
            Index = 5  // 对应第5张图片
            MagFilter = "Point"  // 点过滤（保留边框边缘锐度，避免模糊导致线条变粗）
            MinFilter = "Point"
            MipFilter = "None"
            AddressU = "Clamp"
            AddressV = "Clamp"
        }
    }
}


// ==============================================================
// 顶点输出结构（VS_OUTPUT）：顶点着色器传递给像素着色器的数据
// 通用结构，包含位置、纹理坐标，支持动画/遮罩的条件扩展
// ==============================================================
VertexStruct VS_OUTPUT
{
    float4  vPosition : PDX_POSITION;  // 像素在屏幕上的最终位置（坐标）
    float2  vTexCoord : TEXCOORD0;     // 主纹理坐标（告诉像素该读取边框的哪个部分）
@ifdef ANIMATED  // 开启动画时，包含动画纹理坐标（动态效果的位置信息）
    float4  vAnimatedTexCoord : TEXCOORD1;
@endif
@ifdef MASKING  // 开启遮罩时，包含主遮罩坐标（控制边框显示范围）
    float2  vMaskingTexCoord : TEXCOORD2;
@endif
};


// ==============================================================
// 顶点着色器（VertexShader）：计算边框的位置和基础纹理坐标
// 所有状态共用，功能与其他背景元素一致（仅负责位置转换和坐标传递）
// ==============================================================
VertexShader =
{
    MainCode VertexShader
    [[
        VS_OUTPUT main(const VS_INPUT v )
        {
            VS_OUTPUT Out;
            // 计算屏幕位置：通过投影矩阵将3D世界坐标转为屏幕2D显示坐标
            Out.vPosition  = mul( WorldViewProjectionMatrix, float4( v.vPosition.xyz, 1 ) );
        
            // 传递主纹理坐标（将原始纹理坐标传递给像素着色器）
            Out.vTexCoord = v.vTexCoord;
        
            return Out;
        }
    ]]
}


// ==============================================================
// 像素着色器（PixelShader）：核心逻辑，控制边框的状态动画
// 重点：Up状态的严格时间窗口，Disable状态的双中心叠加燃烧效果
// ==============================================================
PixelShader =
{
    // 1. 状态：Up（正常显示状态，控制边框的可见时间窗口）
    MainCode PixelShaderUp
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取边框的原始颜色（基础线条/花纹色）
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            
            // 【控制参数1：Offset.x】强制隐藏开关
            // 若Offset.x的整数部分+1等于2，则边框完全透明（不显示）
            float value = floor(Offset.x) + 1.f;  // floor取整数部分（如1.9→1）
            if(value == 2)
            {
                return float4(0,0,0,0);  // 全透明（隐藏）
            }
            
            // 计算动画时间：当前时间(Time) - 动画开始时间(AnimationTime)
            float vTime = Time - AnimationTime;
            
            // 时间窗口外（<12秒 或 >34秒）：边框完全透明（不显示）
            // 设计目的：仅在核心内容（如地图、界面组件）活跃的12~34秒内显示，避免干扰其他阶段
            if(vTime < 12.f)
            {
                return float4(0,0,0,0);
            }
            if(vTime > 34.f)
            {
                return float4(0,0,0,0);
            }
            
            // 时间窗口内（12~34秒）：显示原始边框颜色（履行区域界定功能）
            return OutColor;
        }
    ]]

    // 2. 状态：Down（按下状态，边框变暗的交互反馈）
    MainCode PixelShaderDown
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取边框的原始颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                    
        // 开启动画时，混合动画纹理（如点击时边框局部闪烁、变暗波纹）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制边框透明度（如仅显示部分边框的按下效果）
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;  // 遮罩透明区域让对应边框部分不显示按下效果
        #endif
            
            // 用游戏传入的Color参数调整边框整体色调（按下时叠加暗化滤镜）
            OutColor *= Color;

            // 按下时的亮度衰减计算（随时间变暗，与其他背景元素保持一致的交互反馈风格）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 16 );  // 限制值在0~1
            vTime *= vTime;  // 平方运算让变化更平滑（先快后慢，模拟物理按压感）
            vTime = 0.9*0.9 - vTime;  // 反向计算衰减值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（降低亮度）
            OutColor.rgb -= ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 降低RGB亮度

            return OutColor;
        }
    ]]

    // 3. 状态：Disable（禁用状态，边框的双中心叠加燃烧特效）
    MainCode PixelShaderDisable
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取边框的原始颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
            
            // 【控制参数：Offset.x】强制隐藏（同Up状态）
            float value = floor(Offset.x) + 1.f;
            if(value == 2)
            {
                return float4(0,0,0,0);
            }
            
            // 若边框本身完全透明（原始纹理alpha=0，如边框间隙），则不显示任何效果
            if(OutColor.a == 0)
            {
                return float4(0,0,0,0);
            }
            
            // 计算动画时间（当前时间 - 动画开始时间）
            float vTime = Time - AnimationTime;
            
            // 阶段1：10秒前 → 边框完全透明（不显示，等待核心内容加载）
            if(vTime < 10.f)
            {
                return float4(0,0,0,0);
            }
            // 阶段2：10~12秒 → 边框逐渐显示（透明度从0→1，与正常状态的显示时间衔接）
            else if(vTime >= 10.f && vTime < 12.f)
            {
                OutColor.a *= (vTime - 10.f) * 0.5f;  // 10秒时0→12秒时1（完全显示）
            }
            // 阶段3：27秒后 → 显示双中心叠加燃烧效果（边框退场的核心动画）
            else if(vTime > 27.f)
            {
                // 第一个燃烧中心参数（位置：0.5547, 0.5787，约为边框中下部）
                float2 BurnCenter = float2(0.5547f, 0.5787f);  // 精准定位边框下部分布密集区域
                float Aspect = 1.0f;  // 宽高比（正方形，避免燃烧形状拉伸）
                float cTime = vTime - 27.f;  // 第一个燃烧的本地时间（从0开始计时）
                float Radius0 = 0.0f;  // 初始燃烧半径（从点开始）
                float Speed = 0.15f;  // 燃烧速度（中等，0.15>上下层瓦片的0.13/0.133，确保边框先烧完）
                float JagAmp = 0.01f;  // 边缘锯齿幅度（轻微不规则，模拟真实火焰）
                float Freq = 4.f;      // 锯齿频率（中等密度，边缘细节适中）
                float Flow = 0.8f;     // 锯齿流动速度（模拟火焰向上飘动）
                float EdgeWidth = 0.01f; // 燃烧边缘过渡宽度（较窄，边缘清晰）
                float RimWidth = 0.001f; // 火焰光晕宽度（几乎无，避免掩盖边框线条）
                float RimSigma = 0.15f;  // 光晕模糊度（较明显，0.15>其他元素的0.005，增强边框燃烧的视觉冲击）
                float HeatAmp = 0.212f;  // 热扭曲幅度（强扭曲，0.212>>其他元素的0.003，突出边框燃烧的动态感）
                float3 EmberColor = float3(0.8, 0.6, 0.4); // 火焰颜色（浅橙褐色，贴近自然火焰）
                float EmberBoost = 0.55f; // 火焰亮度（较亮，0.55>其他元素的0.05，让边框燃烧更醒目）
                
                // 调用ApplyBurn函数，计算第一个燃烧效果（从下中心开始扩散）
                float4 burn1 = ApplyBurn(v.vTexCoord, MapTexture, BurnCenter, Aspect, cTime, 
                                       Radius0, Speed, JagAmp, Freq, Flow, 
                                       EdgeWidth, RimWidth, RimSigma, HeatAmp, 
                                       EmberColor, EmberBoost);
                float4 finalCol = burn1;  // 初始用第一个燃烧效果
                
                // 27.5秒后，加入第二个燃烧中心（位置：0.5547, 0.1352，约为边框中上部）
                if(vTime > 27.5f)
                {
                    BurnCenter = float2(0.5547f, 0.1352f);  // 精准定位边框上部分布密集区域
                    cTime = vTime - 27.5f;  // 第二个燃烧的本地时间（从0开始）
                    
                    // 计算第二个燃烧效果（参数与第一个相同，仅中心和时间不同）
                    float4 burn2 = ApplyBurn(v.vTexCoord, MapTexture, BurnCenter, Aspect, cTime, 
                                           Radius0, Speed, JagAmp, Freq, Flow, 
                                           EdgeWidth, RimWidth, RimSigma, HeatAmp, 
                                           EmberColor, EmberBoost);
                    
                    // 混合两个燃烧效果（实现上下同时燃烧的叠加感）：
                    float alpha = max(burn1.a, burn2.a);  // 透明度取最大值（重叠区域不透明，避免镂空）
                    // 颜色叠加（第二个燃烧随时间逐渐增强，saturate限制在0~1避免过亮）
                    float3 color = burn1.rgb + (burn2.rgb * saturate((vTime - 27.5) * 3));
                    color = saturate(color);  // 限制颜色亮度在0~1范围
                    color *= alpha;  // 颜色受透明度影响（透明区域无颜色）
                    
                    finalCol = float4(color, alpha);  // 最终混合色（上下燃烧效果叠加）
                }
                
                return finalCol;  // 返回双中心燃烧效果（边框逐渐被火焰覆盖）
            }
            
            // 其他时间（12~27秒）：显示正常边框颜色（履行区域界定功能）
            return OutColor;
        }	
    ]]

    // 4. 状态：Over（悬停状态，边框变亮的交互反馈）
    MainCode PixelShaderOver
    [[
        float4 main( VS_OUTPUT v ) : PDX_COLOR
        {
            // 读取边框的原始颜色
            float4 OutColor = tex2D( MapTexture, v.vTexCoord );
                
        // 开启动画时，混合动画纹理（如悬停时边框发光、局部高亮流动）
        #ifdef ANIMATED
            OutColor = Animate(OutColor, v.vTexCoord, v.vAnimatedTexCoord, 
                              MaskTexture, AnimatedTexture, MaskTexture2, AnimatedTexture2);
        #endif

        // 开启遮罩时，用主遮罩控制透明度（如仅显示部分边框的悬停效果）
        #ifdef MASKING
            float4 MaskColor = tex2D( MaskingTexture, v.vTexCoord );
            OutColor.a *= MaskColor.a;
        #endif

            // 用Color参数调整边框整体色调（悬停时叠加亮化滤镜）
            OutColor *= Color;
            
            // 悬停时的亮度增强计算（随时间变亮，与其他背景元素保持一致的交互反馈风格）
            float vTime = 0.9 - saturate( (Time - AnimationTime) * 4 );  // 变化较慢（系数4，模拟柔和高亮）
            vTime *= vTime;  // 平方运算让变化更平滑
            vTime = 0.9*0.9 - vTime;  // 反向计算增强值
            float4 MixColor = float4( 0.15, 0.15, 0.15, 0 ) * vTime;  // 灰色混合色（提升亮度）
            OutColor.rgb += ( 0.5 + OutColor.rgb ) * MixColor.rgb;  // 增加RGB亮度

            return OutColor;
        }
    ]]
}


// ==============================================================
// 混合状态（BlendState）：控制边框与下层元素的叠加方式
// 与其他背景元素一致，确保透明区域（如燃烧边缘、边框间隙）自然融合
// ==============================================================
BlendState BlendState
{
    BlendEnable = yes  // 启用混合（支持透明度效果）
    SourceBlend = "src_alpha"  // 自身颜色占比=自身透明度
    DestBlend = "inv_src_alpha"  // 下层颜色占比=1-自身透明度
    // 最终颜色 = 边框颜色*透明度 + 下层元素颜色*(1-透明度)
    // 例：燃烧边缘的半透明像素，会自然混合边框和下层背景颜色
}


// ==============================================================
// 效果定义（Effect）：组合顶点和像素着色器，供游戏调用
// 游戏根据边框的状态（正常/按下/禁用/悬停）自动切换
// ==============================================================
Effect Up  // 正常状态：仅12~34秒可见（匹配核心内容活跃期）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderUp"
}

Effect Down  // 按下状态：边框变暗（交互反馈）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDown"
}

Effect Disable  // 禁用状态：27秒后双中心叠加燃烧（边框退场特效）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderDisable"
}

Effect Over  // 悬停状态：边框变亮（交互反馈）
{
    VertexShader = "VertexShader"
    PixelShader = "PixelShaderOver"
}